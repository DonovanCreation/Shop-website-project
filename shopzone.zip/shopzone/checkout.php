<?php
require_once 'layout.php';
requireRole('customer');

$db = getDB();
$customerId = $_SESSION['user_id'];

// Get cart
$stmt = $db->prepare("SELECT c.*, c.id as cart_id, c.quantity, p.id as product_id, p.name, p.price, p.stock, p.image, p.category FROM cart c JOIN products p ON c.product_id = p.id WHERE c.customer_id = ?");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();

if (empty($cartItems)) { header('Location: cart.php'); exit; }

$subtotal = 0;
foreach ($cartItems as $item) $subtotal += $item['price'] * $item['quantity'];

$deliveryServices = [
    'fedex_standard'  => ['name' => 'FedEx Standard', 'logo' => '📦', 'time' => '3-5 business days', 'price' => 8.99],
    'fedex_express'   => ['name' => 'FedEx Express', 'logo' => '⚡', 'time' => '1-2 business days', 'price' => 18.99],
    'ups_ground'      => ['name' => 'UPS Ground', 'logo' => '🟤', 'time' => '3-7 business days', 'price' => 7.99],
    'ups_express'     => ['name' => 'UPS Express', 'logo' => '🚀', 'time' => '1-3 business days', 'price' => 16.99],
    'dhl_express'     => ['name' => 'DHL Express', 'logo' => '✈️', 'time' => '2-4 business days', 'price' => 14.99],
    'usps_priority'   => ['name' => 'USPS Priority', 'logo' => '🇺🇸', 'time' => '2-3 business days', 'price' => 9.99],
    'free_shipping'   => ['name' => 'Free Shipping', 'logo' => '🎁', 'time' => '5-10 business days', 'price' => 0.00],
];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $city = trim($_POST['city'] ?? '');
    $postal = trim($_POST['postal_code'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $payment = $_POST['payment_method'] ?? '';
    $delivery = $_POST['delivery_service'] ?? '';

    if (!$fullName) $errors[] = 'Full name is required.';
    if (!$address) $errors[] = 'Address is required.';
    if (!$city) $errors[] = 'City is required.';
    if (!$postal) $errors[] = 'Postal code is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$payment) $errors[] = 'Please select a payment method.';
    if (!$delivery || !isset($deliveryServices[$delivery])) $errors[] = 'Please select a delivery service.';

    if (empty($errors)) {
        $deliveryCost = $deliveryServices[$delivery]['price'];
        $total = $subtotal + $deliveryCost;
        $addressStr = "$fullName, $address, $city, $postal, $country";
        $deliveryLabel = $deliveryServices[$delivery]['name'];

        $db->prepare("INSERT INTO orders (customer_id, total, address, city, postal_code, country, payment_method, delivery_service, status) VALUES (?,?,?,?,?,?,?,?,'processing')")
           ->execute([$customerId, $total, $addressStr, $city, $postal, $country, $payment, $deliveryLabel]);
        $orderId = $db->lastInsertId();

        foreach ($cartItems as $item) {
            $db->prepare("INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?,?,?,?,?)")
               ->execute([$orderId, $item['product_id'], $item['name'], $item['quantity'], $item['price']]);
            $db->prepare("UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?")->execute([$item['quantity'], $item['product_id']]);
        }

        $db->prepare("DELETE FROM cart WHERE customer_id = ?")->execute([$customerId]);

        header("Location: order_confirm.php?id={$orderId}");
        exit;
    }
}

$paymentMethods = [
    'credit_card' => ['label' => t('credit_card'), 'icon' => '💳'],
    'paypal'      => ['label' => t('paypal'), 'icon' => '🅿️'],
    'crypto'      => ['label' => t('crypto'), 'icon' => '₿'],
    'cod'         => ['label' => t('cod'), 'icon' => '💵'],
];

$selectedDelivery = $_POST['delivery_service'] ?? 'fedex_standard';
$selectedPayment = $_POST['payment_method'] ?? 'credit_card';
$deliveryCost = $deliveryServices[$selectedDelivery]['price'] ?? 8.99;
$total = $subtotal + $deliveryCost;

renderHead(t('checkout'));
renderSidebar('cart');
renderTopbar('🚀 ' . t('checkout'), false, true);
renderFlash();
?>

<!-- Steps -->
<div class="checkout-steps fade-in">
  <div class="step done"><div class="step-num">✓</div><span>Cart</span></div>
  <div class="step-divider"></div>
  <div class="step active"><div class="step-num">2</div><span><?= t('shipping_address') ?></span></div>
  <div class="step-divider"></div>
  <div class="step"><div class="step-num">3</div><span><?= t('payment_method') ?></span></div>
  <div class="step-divider"></div>
  <div class="step"><div class="step-num">4</div><span>Confirm</span></div>
</div>

<form method="POST" id="checkout-form">
<div class="checkout-layout fade-in">

  <div style="display:flex;flex-direction:column;gap:20px">

    <!-- Shipping Address -->
    <div class="card">
      <div class="card-header"><h2>📍 <?= t('shipping_address') ?></h2></div>
      <div class="card-body">
        <?php if ($errors): ?>
          <div class="flash flash-error">
            <span class="flash-icon">✕</span>
            <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
          </div>
        <?php endif; ?>
        <div class="form-group">
          <label class="form-label">👤 <?= t('full_name') ?> *</label>
          <input type="text" name="full_name" class="form-control" required
                 value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" placeholder="John Doe">
        </div>
        <div class="form-group">
          <label class="form-label">🏠 <?= t('address') ?> *</label>
          <input type="text" name="address" class="form-control" required
                 value="<?= htmlspecialchars($_POST['address'] ?? '') ?>" placeholder="123 Main Street, Apt 4B">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">🌆 <?= t('city') ?> *</label>
            <input type="text" name="city" class="form-control" required
                   value="<?= htmlspecialchars($_POST['city'] ?? '') ?>" placeholder="New York">
          </div>
          <div class="form-group">
            <label class="form-label">📮 <?= t('postal_code') ?> *</label>
            <input type="text" name="postal_code" class="form-control" required
                   value="<?= htmlspecialchars($_POST['postal_code'] ?? '') ?>" placeholder="10001">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🌍 <?= t('country') ?> *</label>
          <select name="country" class="form-control" required>
            <option value="">Select country...</option>
            <?php
            $countries = ['United States','Canada','United Kingdom','Australia','Germany','France','Japan','South Korea','Indonesia','Singapore','Malaysia','Thailand','Philippines','India','Brazil','Mexico','Netherlands','Spain','Italy','Sweden'];
            foreach ($countries as $c) {
                $sel = ($_POST['country'] ?? '') === $c ? 'selected' : '';
                echo "<option value=\"{$c}\" {$sel}>{$c}</option>";
            }
            ?>
          </select>
        </div>
      </div>
    </div>

    <!-- Payment Method -->
    <div class="card">
      <div class="card-header"><h2>💳 <?= t('payment_method') ?></h2></div>
      <div class="card-body">
        <div class="payment-options">
          <?php foreach ($paymentMethods as $key => $pm): ?>
            <label class="payment-option <?= $selectedPayment === $key ? 'selected' : '' ?>">
              <input type="radio" name="payment_method" value="<?= $key ?>" <?= $selectedPayment === $key ? 'checked' : '' ?> required>
              <div class="payment-icon"><?= $pm['icon'] ?></div>
              <div class="payment-label"><?= $pm['label'] ?></div>
            </label>
          <?php endforeach; ?>
        </div>

        <!-- Card fields (shown when credit card selected) -->
        <div id="card-fields" style="margin-top:16px;<?= $selectedPayment !== 'credit_card' ? 'display:none' : '' ?>">
          <div class="form-group">
            <label class="form-label">Card Number</label>
            <input type="text" class="form-control" placeholder="•••• •••• •••• ••••" maxlength="19">
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Expiry</label>
              <input type="text" class="form-control" placeholder="MM/YY">
            </div>
            <div class="form-group">
              <label class="form-label">CVV</label>
              <input type="text" class="form-control" placeholder="•••">
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Delivery Service -->
    <div class="card">
      <div class="card-header"><h2>🚚 <?= t('delivery_service') ?></h2></div>
      <div class="card-body">
        <div class="delivery-options">
          <?php foreach ($deliveryServices as $key => $ds): ?>
            <label class="delivery-option <?= $selectedDelivery === $key ? 'selected' : '' ?>">
              <input type="radio" name="delivery_service" value="<?= $key ?>"
                     <?= $selectedDelivery === $key ? 'checked' : '' ?> required
                     onchange="updateDeliveryTotal(<?= $ds['price'] ?>)">
              <div class="delivery-logo"><?= $ds['logo'] ?></div>
              <div class="delivery-info">
                <div class="delivery-name"><?= $ds['name'] ?></div>
                <div class="delivery-time">🕐 <?= $ds['time'] ?></div>
              </div>
              <div class="delivery-price"><?= $ds['price'] == 0 ? 'FREE' : '$' . number_format($ds['price'], 2) ?></div>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Order Summary sidebar -->
  <div>
    <div class="order-summary" style="position:sticky;top:80px">
      <h3>📋 <?= t('checkout') ?> Summary</h3>

      <?php foreach ($cartItems as $item): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
          <div style="width:40px;height:40px;border-radius:8px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">
            <?php if ($item['image'] && file_exists(__DIR__ . '/uploads/' . $item['image'])): ?>
              <img src="uploads/<?= htmlspecialchars($item['image']) ?>" style="width:100%;height:100%;object-fit:cover;border-radius:8px">
            <?php else: ?>
              <?= categoryEmoji($item['category']) ?>
            <?php endif; ?>
          </div>
          <div style="flex:1;font-size:13px">
            <div style="font-weight:600"><?= htmlspecialchars($item['name']) ?></div>
            <div style="color:var(--text-light)">x<?= $item['quantity'] ?></div>
          </div>
          <div style="font-weight:700;font-size:14px">$<?= number_format($item['price'] * $item['quantity'], 2) ?></div>
        </div>
      <?php endforeach; ?>

      <div class="summary-row" style="margin-top:8px">
        <span>Subtotal</span>
        <span>$<?= number_format($subtotal, 2) ?></span>
      </div>
      <div class="summary-row">
        <span><?= t('shipping_fee') ?></span>
        <span id="delivery-cost">$<?= number_format($deliveryCost, 2) ?></span>
      </div>
      <div class="summary-total">
        <span><?= t('order_total') ?></span>
        <span id="order-total" style="color:var(--primary)">$<?= number_format($total, 2) ?></span>
      </div>

      <br>
      <button type="submit" class="btn btn-primary btn-block btn-lg">
        ✅ <?= t('place_order') ?>
      </button>
      <a href="cart.php" class="btn btn-outline btn-block" style="margin-top:10px;justify-content:center;display:flex">
        ← <?= t('cart') ?>
      </a>
    </div>
  </div>
</div>
</form>

<script>
const subtotal = <?= $subtotal ?>;
const deliveryPrices = <?= json_encode(array_combine(
    array_keys($deliveryServices),
    array_column($deliveryServices, 'price')
)) ?>;

function updateDeliveryTotal(price) {
    const total = subtotal + price;
    document.getElementById('delivery-cost').textContent = price === 0 ? 'FREE' : '$' + price.toFixed(2);
    document.getElementById('order-total').textContent = '$' + total.toFixed(2);
}

// Payment method toggle card fields
document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
    radio.addEventListener('change', function() {
        const cardFields = document.getElementById('card-fields');
        if (cardFields) {
            cardFields.style.display = this.value === 'credit_card' ? 'block' : 'none';
        }
    });
});
</script>

<?php renderFooter(); ?>

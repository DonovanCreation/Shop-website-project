<?php
require_once 'layout.php';
requireRole('seller');

$db = getDB();
$sellerId = $_SESSION['user_id'];

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $pid = (int)$_POST['product_id'];
    // Only delete own product
    $stmt = $db->prepare("SELECT image FROM products WHERE id = ? AND seller_id = ?");
    $stmt->execute([$pid, $sellerId]);
    $prod = $stmt->fetch();
    if ($prod) {
        if ($prod['image'] && file_exists(__DIR__ . '/uploads/' . $prod['image'])) {
            unlink(__DIR__ . '/uploads/' . $prod['image']);
        }
        $db->prepare("DELETE FROM products WHERE id = ? AND seller_id = ?")->execute([$pid, $sellerId]);
        setFlash('success', t('product_deleted'));
    }
    header('Location: seller.php');
    exit;
}

// Stats
$stats = $db->prepare("SELECT COUNT(*) as cnt, SUM(price * stock) as value FROM products WHERE seller_id = ?");
$stats->execute([$sellerId]);
$pstats = $stats->fetch();

$ostats = $db->prepare("SELECT COUNT(*) as cnt, SUM(total) as rev FROM orders o
    INNER JOIN order_items oi ON o.id = oi.order_id
    INNER JOIN products p ON oi.product_id = p.id
    WHERE p.seller_id = ?");
$ostats->execute([$sellerId]);
$ostats = $ostats->fetch();

// Products
$search = $_GET['s'] ?? '';
$stmt = $db->prepare("SELECT * FROM products WHERE seller_id = ? AND name LIKE ? ORDER BY created_at DESC");
$stmt->execute([$sellerId, "%{$search}%"]);
$products = $stmt->fetchAll();

renderHead(t('seller_dashboard'));
renderSidebar('dashboard');
renderTopbar(t('seller_dashboard'), false, false);
renderFlash();
?>

<div class="stats-grid fade-in">
  <div class="stat-card">
    <div class="stat-icon orange">📦</div>
    <div>
      <div class="stat-value"><?= $pstats['cnt'] ?></div>
      <div class="stat-label"><?= t('total_products') ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue">🧾</div>
    <div>
      <div class="stat-value"><?= $ostats['cnt'] ?? 0 ?></div>
      <div class="stat-label"><?= t('total_orders') ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">💰</div>
    <div>
      <div class="stat-value">$<?= number_format($ostats['rev'] ?? 0, 0) ?></div>
      <div class="stat-label"><?= t('revenue') ?></div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon gold">📈</div>
    <div>
      <div class="stat-value"><?= $pstats['cnt'] > 0 ? round(($ostats['cnt'] ?? 0) / $pstats['cnt'], 1) : 0 ?></div>
      <div class="stat-label">Orders / Product</div>
    </div>
  </div>
</div>

<div class="card fade-in">
  <div class="card-header">
    <h2>📦 <?= t('my_products') ?></h2>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <form method="GET" style="display:flex;gap:8px">
        <input type="text" name="s" class="form-control" style="width:220px;padding:8px 14px"
               placeholder="<?= t('search') ?>" value="<?= htmlspecialchars($search) ?>">
        <button type="submit" class="btn btn-secondary btn-sm">🔍</button>
      </form>
      <a href="product_add.php" class="btn btn-primary btn-sm">➕ <?= t('add_product') ?></a>
    </div>
  </div>

  <?php if (empty($products)): ?>
    <div class="empty-state">
      <div class="empty-icon">📦</div>
      <div class="empty-title"><?= t('no_products') ?></div>
      <div class="empty-sub">Start by adding your first product!</div>
      <br><a href="product_add.php" class="btn btn-primary">➕ <?= t('add_product') ?></a>
    </div>
  <?php else: ?>
    <?php foreach ($products as $p): ?>
      <div class="product-list-item">
        <div class="product-thumb">
          <?= productImage($p) ?>
        </div>
        <div class="product-list-info">
          <div class="product-list-name"><?= htmlspecialchars($p['name']) ?></div>
          <div class="product-list-meta">
            <?= htmlspecialchars($p['category']) ?> ·
            <?= t('stock') ?>: <?= $p['stock'] ?> ·
            <?= date('M d, Y', strtotime($p['created_at'])) ?>
          </div>
        </div>
        <span class="product-list-price">$<?= number_format($p['price'], 2) ?></span>
        <span class="badge <?= $p['stock'] > 0 ? 'badge-success' : 'badge-danger' ?>">
          <?= $p['stock'] > 0 ? t('in_stock') : t('out_of_stock') ?>
        </span>
        <div class="product-actions">
          <a href="product_add.php?edit=<?= $p['id'] ?>" class="btn btn-sm btn-outline"><?= t('edit') ?></a>
          <form method="POST" style="display:inline">
            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
            <button type="submit" name="delete_product" value="1" class="btn btn-sm btn-danger"
                    data-confirm="<?= t('delete') ?> '<?= htmlspecialchars($p['name']) ?>'?"
                    onclick="return confirm('Delete this product?')">
              <?= t('delete') ?>
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php renderFooter(); ?>

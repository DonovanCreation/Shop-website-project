<?php
require_once 'layout.php';
requireRole('customer');

$db = getDB();
$category = $_GET['cat'] ?? 'all';
$sort = $_GET['sort'] ?? 'newest';

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $productId = (int)$_POST['product_id'];
    $qty = max(1, (int)($_POST['quantity'] ?? 1));
    $customerId = $_SESSION['user_id'];

    // Check existing cart item
    $stmt = $db->prepare("SELECT id, quantity FROM cart WHERE customer_id = ? AND product_id = ?");
    $stmt->execute([$customerId, $productId]);
    $existing = $stmt->fetch();

    if ($existing) {
        $db->prepare("UPDATE cart SET quantity = quantity + ? WHERE id = ?")->execute([$qty, $existing['id']]);
    } else {
        $db->prepare("INSERT INTO cart (customer_id, product_id, quantity) VALUES (?,?,?)")->execute([$customerId, $productId, $qty]);
    }
    setFlash('success', t('cart_added'));
    header('Location: shop.php' . ($category !== 'all' ? "?cat={$category}" : ''));
    exit;
}

// Get categories
$catStmt = $db->query("SELECT DISTINCT category FROM products WHERE stock > 0 ORDER BY category");
$categories = $catStmt->fetchAll(PDO::FETCH_COLUMN);

// Get products
$orderMap = [
    'newest' => 'p.created_at DESC',
    'price-asc' => 'p.price ASC',
    'price-desc' => 'p.price DESC',
    'name' => 'p.name ASC',
];
$orderBy = $orderMap[$sort] ?? 'p.created_at DESC';

if ($category !== 'all') {
    $stmt = $db->prepare("SELECT p.*, u.username as seller_name FROM products p JOIN users u ON p.seller_id = u.id WHERE p.category = ? ORDER BY {$orderBy}");
    $stmt->execute([$category]);
} else {
    $stmt = $db->query("SELECT p.*, u.username as seller_name FROM products p JOIN users u ON p.seller_id = u.id ORDER BY {$orderBy}");
}
$products = $stmt->fetchAll();

renderHead(t('shop'));
renderSidebar('shop');
renderTopbar('🛍️ ' . t('shop'), true, true);
renderFlash();
?>

<!-- Filter bar -->
<div class="filter-bar">
  <a href="shop.php" class="filter-chip <?= $category === 'all' ? 'active' : '' ?>" data-cat="all">
    🏪 <?= t('all_categories') ?>
  </a>
  <?php foreach ($categories as $cat): ?>
    <a href="shop.php?cat=<?= urlencode($cat) ?>&sort=<?= $sort ?>"
       class="filter-chip <?= $category === $cat ? 'active' : '' ?>"
       data-cat="<?= htmlspecialchars($cat) ?>">
      <?= categoryEmoji($cat) ?> <?= htmlspecialchars($cat) ?>
    </a>
  <?php endforeach; ?>

  <div style="margin-left:auto;display:flex;align-items:center;gap:8px">
    <span style="font-size:13px;font-weight:600;color:var(--text-light)"><?= t('sort_by') ?>:</span>
    <select id="sort-select" class="sort-select" onchange="window.location.href='shop.php?cat=<?= urlencode($category) ?>&sort='+this.value">
      <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>>Newest</option>
      <option value="price-asc" <?= $sort === 'price-asc' ? 'selected' : '' ?>>Price: Low→High</option>
      <option value="price-desc" <?= $sort === 'price-desc' ? 'selected' : '' ?>>Price: High→Low</option>
      <option value="name" <?= $sort === 'name' ? 'selected' : '' ?>>Name A→Z</option>
    </select>
  </div>
</div>

<?php if (empty($products)): ?>
  <div class="empty-state">
    <div class="empty-icon">🔍</div>
    <div class="empty-title"><?= t('no_products') ?></div>
    <div class="empty-sub">Try a different category or check back later.</div>
    <br><a href="shop.php" class="btn btn-primary"><?= t('all_categories') ?></a>
  </div>
<?php else: ?>
  <div class="products-grid fade-in">
    <?php foreach ($products as $p): ?>
      <div class="product-card"
           data-name="<?= htmlspecialchars($p['name']) ?>"
           data-category="<?= htmlspecialchars($p['category']) ?>"
           data-price="<?= $p['price'] ?>">

        <?php if ($p['created_at'] && strtotime($p['created_at']) > strtotime('-7 days')): ?>
          <div class="product-badge">NEW</div>
        <?php endif; ?>

        <div class="product-img">
          <?= productImage($p) ?>
        </div>

        <div class="product-info">
          <div class="product-category"><?= categoryEmoji($p['category']) ?> <?= htmlspecialchars($p['category']) ?></div>
          <div class="product-name"><?= htmlspecialchars($p['name']) ?></div>

          <?php if ($p['description']): ?>
            <div style="font-size:12px;color:var(--text-light);margin-bottom:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">
              <?= htmlspecialchars($p['description']) ?>
            </div>
          <?php endif; ?>

          <div class="product-price">$<?= number_format($p['price'], 2) ?></div>

          <?php if ($p['stock'] <= 0): ?>
            <div class="product-stock out">❌ <?= t('out_of_stock') ?></div>
          <?php elseif ($p['stock'] <= 5): ?>
            <div class="product-stock low">⚠️ Only <?= $p['stock'] ?> left!</div>
          <?php else: ?>
            <div class="product-stock">✅ <?= t('in_stock') ?> (<?= $p['stock'] ?>)</div>
          <?php endif; ?>

          <form method="POST">
            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
            <div class="qty-input-wrap">
              <label><?= t('quantity') ?>:</label>
              <div class="qty-control">
                <button type="button" class="qty-btn" data-action="dec">−</button>
                <input type="number" name="quantity" class="qty-val" value="1" min="1" max="<?= $p['stock'] ?>">
                <button type="button" class="qty-btn" data-action="inc">+</button>
              </div>
            </div>
            <button type="submit" name="add_to_cart" value="1"
                    class="btn-add-cart" <?= $p['stock'] <= 0 ? 'disabled' : '' ?>>
              🛒 <?= t('add_to_cart') ?>
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php renderFooter(); ?>

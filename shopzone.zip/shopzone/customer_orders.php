<?php
require_once 'layout.php';
requireRole('customer');

$db = getDB();
$customerId = $_SESSION['user_id'];

$stmt = $db->prepare("SELECT * FROM orders WHERE customer_id = ? ORDER BY created_at DESC");
$stmt->execute([$customerId]);
$orders = $stmt->fetchAll();

renderHead(t('orders'));
renderSidebar('orders');
renderTopbar('📋 ' . t('orders'), false, true);
renderFlash();
?>

<div class="card fade-in">
  <div class="card-header">
    <h2>📋 <?= t('orders') ?></h2>
    <span class="badge badge-processing"><?= count($orders) ?> total</span>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state">
      <div class="empty-icon">📋</div>
      <div class="empty-title"><?= t('no_orders') ?></div>
      <div class="empty-sub">Your order history will appear here.</div>
      <br><a href="shop.php" class="btn btn-primary">🛍️ Start Shopping</a>
    </div>
  <?php else: ?>
    <?php foreach ($orders as $order):
      $istmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
      $istmt->execute([$order['id']]);
      $items = $istmt->fetchAll();
    ?>
    <div style="border-bottom:1px solid var(--border);padding:20px 24px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:12px">
        <div>
          <div style="font-family:'Outfit',sans-serif;font-weight:800;font-size:16px"><?= t('order_id') ?><?= $order['id'] ?></div>
          <div style="font-size:12px;color:var(--text-light);margin-top:2px">
            📅 <?= date('M d, Y H:i', strtotime($order['created_at'])) ?> ·
            🚚 <?= htmlspecialchars($order['delivery_service']) ?>
          </div>
        </div>
        <div style="text-align:right">
          <span class="badge badge-<?= $order['status'] ?>"><?= t($order['status']) ?></span>
          <div style="font-family:'Outfit',sans-serif;font-weight:800;font-size:18px;color:var(--primary);margin-top:4px">
            $<?= number_format($order['total'], 2) ?>
          </div>
        </div>
      </div>

      <div style="display:flex;flex-wrap:wrap;gap:8px">
        <?php foreach ($items as $item): ?>
          <div style="background:var(--bg);border-radius:8px;padding:8px 12px;font-size:13px">
            <span style="font-weight:600"><?= htmlspecialchars($item['product_name']) ?></span>
            <span style="color:var(--text-light);margin-left:6px">×<?= $item['quantity'] ?> · $<?= number_format($item['price'], 2) ?></span>
          </div>
        <?php endforeach; ?>
      </div>

      <div style="margin-top:10px;font-size:13px;color:var(--text-light)">
        📍 <?= htmlspecialchars($order['address']) ?>
      </div>
    </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php renderFooter(); ?>

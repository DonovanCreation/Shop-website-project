<?php
require_once 'layout.php';
requireRole('customer');

$db = getDB();
$customerId = $_SESSION['user_id'];

// Handle remove
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_item'])) {
    $db->prepare("DELETE FROM cart WHERE id = ? AND customer_id = ?")->execute([(int)$_POST['cart_id'], $customerId]);
    header('Location: cart.php'); exit;
}

// Handle qty update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty'])) {
    $cartId = (int)$_POST['cart_id'];
    $qty = max(1, (int)$_POST['quantity']);
    $db->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND customer_id = ?")->execute([$qty, $cartId, $customerId]);
    header('Location: cart.php'); exit;
}

// Get cart items
$stmt = $db->prepare("
    SELECT c.id as cart_id, c.quantity, p.id as product_id, p.name, p.price, p.stock, p.image, p.category
    FROM cart c JOIN products p ON c.product_id = p.id
    WHERE c.customer_id = ?
");
$stmt->execute([$customerId]);
$cartItems = $stmt->fetchAll();

$subtotal = 0;
foreach ($cartItems as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}
$shipping = $subtotal > 50 ? 0 : 5.99;
$total = $subtotal + $shipping;

renderHead(t('cart'));
renderSidebar('cart');
renderTopbar('🛒 ' . t('cart'), false, false);
renderFlash();
?>

<?php if (empty($cartItems)): ?>
  <div class="empty-state fade-in">
    <div class="empty-icon">🛒</div>
    <div class="empty-title">Your cart is empty</div>
    <div class="empty-sub">Discover amazing products in our shop!</div>
    <br><a href="shop.php" class="btn btn-primary btn-lg">🛍️ <?= t('continue_shopping') ?></a>
  </div>
<?php else: ?>
  <div class="cart-layout fade-in">

    <!-- Cart items -->
    <div class="card">
      <div class="card-header">
        <h2>🛒 <?= t('cart') ?> <span style="font-weight:400;font-size:16px;color:var(--text-light)">(<?= count($cartItems) ?> items)</span></h2>
        <a href="shop.php" class="btn btn-sm btn-outline">+ <?= t('continue_shopping') ?></a>
      </div>

      <?php foreach ($cartItems as $item): ?>
        <div class="cart-item cart-row" data-price="<?= $item['price'] ?>">
          <div class="cart-item-img">
            <?php if ($item['image'] && file_exists(__DIR__ . '/uploads/' . $item['image'])): ?>
              <img src="uploads/<?= htmlspecialchars($item['image']) ?>">
            <?php else: ?>
              <?= categoryEmoji($item['category']) ?>
            <?php endif; ?>
          </div>

          <div class="cart-item-info">
            <div class="cart-item-name"><?= htmlspecialchars($item['name']) ?></div>
            <div class="cart-item-price">$<?= number_format($item['price'], 2) ?> each</div>
            <?php if ($item['quantity'] > $item['stock']): ?>
              <div style="font-size:12px;color:#f44336;margin-top:4px">⚠️ Only <?= $item['stock'] ?> in stock</div>
            <?php endif; ?>
          </div>

          <!-- Qty update form -->
          <form method="POST" data-autosubmit="1">
            <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
            <div class="qty-control">
              <button type="button" class="qty-btn" data-action="dec">−</button>
              <input type="number" name="quantity" class="qty-val" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>">
              <button type="button" class="qty-btn" data-action="inc">+</button>
            </div>
            <button type="submit" name="update_qty" value="1" style="display:none">Update</button>
          </form>

          <div class="row-total" style="font-family:'Outfit',sans-serif;font-weight:800;font-size:16px;min-width:70px;text-align:right">
            $<?= number_format($item['price'] * $item['quantity'], 2) ?>
          </div>

          <!-- Remove -->
          <form method="POST">
            <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
            <button type="submit" name="remove_item" value="1"
                    class="btn btn-sm btn-danger" title="<?= t('remove') ?>">✕</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>

    <!-- Order summary -->
    <div class="order-summary">
      <h3>📋 Order Summary</h3>

      <div class="summary-row">
        <span>Subtotal</span>
        <span id="summary-subtotal">$<?= number_format($subtotal, 2) ?></span>
      </div>
      <div class="summary-row">
        <span><?= t('shipping_fee') ?></span>
        <span id="summary-shipping"><?= $shipping == 0 ? 'FREE' : '$' . number_format($shipping, 2) ?></span>
      </div>
      <?php if ($shipping == 0): ?>
        <div style="font-size:12px;color:var(--accent-green);font-weight:600;padding:4px 0">✅ Free shipping on orders over $50!</div>
      <?php else: ?>
        <div style="font-size:12px;color:var(--text-light);padding:4px 0">💡 Spend $<?= number_format(50 - $subtotal, 2) ?> more for free shipping!</div>
      <?php endif; ?>
      <div class="summary-total">
        <span>Total</span>
        <span id="summary-total" style="color:var(--primary)">$<?= number_format($total, 2) ?></span>
      </div>

      <br>
      <a href="checkout.php" class="btn btn-primary btn-block btn-lg">
        🚀 <?= t('checkout') ?> →
      </a>
    </div>
  </div>
<?php endif; ?>

<?php renderFooter(); ?>

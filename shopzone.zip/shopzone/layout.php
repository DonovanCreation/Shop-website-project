<?php
require_once __DIR__ . '/init.php';

function renderHead($title = 'ShopZone') {
    $lang = getLang();
    echo "<!DOCTYPE html>
<html lang=\"{$lang}\">
<head>
<meta charset=\"UTF-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<title>{$title} – ShopZone</title>
<link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>";
}

function renderSidebar($active = '') {
    $user = getCurrentUser();
    $role = $_SESSION['role'] ?? '';
    $cartCount = getCartCount();
    $initial = strtoupper(substr($user['username'] ?? 'U', 0, 1));

    $sellerNav = [
        ['icon' => '📊', 'key' => 'home', 'label' => t('home'), 'href' => 'seller.php', 'id' => 'dashboard'],
        ['icon' => '📦', 'key' => 'my_listings', 'label' => t('my_listings'), 'href' => 'seller.php?view=products', 'id' => 'products'],
        ['icon' => '➕', 'key' => 'add_product', 'label' => t('add_product'), 'href' => 'product_add.php', 'id' => 'add_product'],
        ['icon' => '🧾', 'key' => 'seller_orders', 'label' => t('seller_orders'), 'href' => 'seller_orders.php', 'id' => 'orders'],
        ['icon' => '⚙️', 'key' => 'settings', 'label' => t('settings'), 'href' => 'settings.php', 'id' => 'settings'],
    ];

    $customerNav = [
        ['icon' => '🏠', 'key' => 'home', 'label' => t('home'), 'href' => 'shop.php', 'id' => 'shop'],
        ['icon' => '🛒', 'key' => 'cart', 'label' => t('cart'), 'href' => 'cart.php', 'id' => 'cart', 'badge' => $cartCount],
        ['icon' => '📋', 'key' => 'orders', 'label' => t('orders'), 'href' => 'customer_orders.php', 'id' => 'orders'],
        ['icon' => '⚙️', 'key' => 'settings', 'label' => t('settings'), 'href' => 'settings.php', 'id' => 'settings'],
    ];

    $nav = $role === 'seller' ? $sellerNav : $customerNav;
    $roleLabel = $role === 'seller' ? '🏪 Seller' : '🛒 Customer';

    echo "<div class='sidebar-overlay'></div>";
    echo "<aside class='sidebar'>";
    echo "<div class='sidebar-logo'>
        <div class='logo-icon'>🛍️</div>
        <div class='logo-text'>Shop<span>Zone</span></div>
      </div>";
    echo "<nav class='sidebar-nav'>";
    echo "<div class='nav-section-label'>Menu</div>";

    foreach ($nav as $item) {
        $cls = $active === $item['id'] ? 'active' : '';
        $badge = isset($item['badge']) && $item['badge'] > 0
            ? "<span class='cart-badge' style='position:static;margin-left:auto'>{$item['badge']}</span>"
            : '';
        echo "<a href='{$item['href']}' class='nav-item {$cls}'>
            <span class='nav-icon'>{$item['icon']}</span>
            <span>{$item['label']}</span>
            {$badge}
          </a>";
    }

    echo "</nav>";
    echo "<div class='sidebar-footer'>
        <div class='user-badge'>
          <div class='user-avatar'>{$initial}</div>
          <div class='user-info'>
            <div class='user-name'>" . htmlspecialchars($user['username']) . "</div>
            <div class='user-role'>{$roleLabel}</div>
          </div>
        </div>
      </div>";
    echo "</aside>";

    echo "<div class='main-content'>";
}

function renderTopbar($title, $showSearch = false, $showCart = false) {
    $cartCount = getCartCount();
    echo "<header class='topbar'>
        <button class='menu-toggle' aria-label='Menu'>☰</button>
        <h1 class='topbar-title'>{$title}</h1>";

    if ($showSearch) {
        echo "<div class='search-bar'>
            <span class='search-icon'>🔍</span>
            <input type='text' id='live-search' placeholder='" . t('search') . "'>
          </div>";
    }

    if ($showCart) {
        $badge = $cartCount > 0 ? "<span class='cart-badge'>{$cartCount}</span>" : '';
        echo "<a href='cart.php' class='cart-btn'>🛒{$badge}</a>";
    }

    echo "</header>";
    echo "<main class='page-content'>";
}

function renderFooter() {
    echo "</main></div>";
    echo "<script src='script.js'></script>";
    echo "</body></html>";
}

function categoryEmoji($cat) {
    $map = [
        'Electronics' => '🔌', 'Fashion' => '👗', 'Kitchen' => '🍳',
        'Home' => '🏠', 'Sports' => '⚽', 'Books' => '📚',
        'Beauty' => '💄', 'Toys' => '🧸', 'Garden' => '🌿', 'General' => '📦',
    ];
    return $map[$cat] ?? '📦';
}

function productImage($product) {
    if (!empty($product['image']) && file_exists(__DIR__ . '/uploads/' . $product['image'])) {
        return "<img src='uploads/" . htmlspecialchars($product['image']) . "' alt='" . htmlspecialchars($product['name']) . "'>";
    }
    return categoryEmoji($product['category'] ?? 'General');
}
?>

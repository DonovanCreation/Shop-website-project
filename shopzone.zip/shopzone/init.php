<?php
session_start();

// Database setup
function getDB() {
    static $db = null;
    if ($db === null) {
        $db = new PDO('sqlite:' . __DIR__ . '/shopzone.db');
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        initDB($db);
    }
    return $db;
}

function initDB($db) {
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'customer',
        email TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        description TEXT,
        price REAL NOT NULL,
        stock INTEGER DEFAULT 0,
        category TEXT DEFAULT 'General',
        image TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (seller_id) REFERENCES users(id)
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 1,
        FOREIGN KEY (customer_id) REFERENCES users(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        total REAL NOT NULL,
        address TEXT,
        city TEXT,
        postal_code TEXT,
        country TEXT,
        payment_method TEXT,
        delivery_service TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES users(id)
    )");

    $db->exec("CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        price REAL NOT NULL,
        FOREIGN KEY (order_id) REFERENCES orders(id)
    )");

    // Seed demo users
    $stmt = $db->query("SELECT COUNT(*) as cnt FROM users");
    if ($stmt->fetch()['cnt'] == 0) {
        $db->exec("INSERT INTO users (username, password, role) VALUES
            ('seller', '" . password_hash('seller123', PASSWORD_DEFAULT) . "', 'seller'),
            ('customer', '" . password_hash('customer123', PASSWORD_DEFAULT) . "', 'customer')");

        // Demo products
        $sellerId = $db->lastInsertId() - 1;
        $db->exec("INSERT INTO products (seller_id, name, description, price, stock, category, image) VALUES
            ($sellerId, 'Wireless Earbuds Pro', 'Premium sound quality with 30hr battery life, noise cancelling', 49.99, 150, 'Electronics', ''),
            ($sellerId, 'Smart Watch Ultra', 'Health tracking, GPS, 7-day battery, waterproof IP68', 129.99, 80, 'Electronics', ''),
            ($sellerId, 'Leather Crossbody Bag', 'Genuine leather, multiple compartments, adjustable strap', 79.99, 60, 'Fashion', ''),
            ($sellerId, 'Portable Blender', 'USB rechargeable, 6-blade, perfect for smoothies on the go', 34.99, 200, 'Kitchen', ''),
            ($sellerId, 'LED Desk Lamp', 'Touch control, 5 color modes, USB charging port, foldable arm', 27.99, 120, 'Home', ''),
            ($sellerId, 'Running Shoes X1', 'Lightweight mesh, cushioned sole, breathable, unisex', 64.99, 90, 'Sports', '')");
    }
}

// Auth helpers
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        header('Location: index.php');
        exit;
    }
}

function getCartCount() {
    if (!isLoggedIn() || $_SESSION['role'] !== 'customer') return 0;
    $db = getDB();
    $stmt = $db->prepare("SELECT SUM(quantity) as total FROM cart WHERE customer_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch();
    return $row['total'] ?? 0;
}

// Language helper
function getLang() {
    return $_SESSION['lang'] ?? 'en';
}

function t($key) {
    require_once __DIR__ . '/lang.php';
    $lang = getLang();
    $translations = getTranslations();
    return $translations[$lang][$key] ?? $translations['en'][$key] ?? $key;
}

// Flash messages
function setFlash($type, $msg) {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function renderFlash() {
    $flash = getFlash();
    if ($flash) {
        $icon = $flash['type'] === 'success' ? '✓' : '✕';
        echo "<div class='flash flash-{$flash['type']}'><span class='flash-icon'>{$icon}</span>{$flash['msg']}</div>";
    }
}

getDB(); // Initialize DB on every request
?>

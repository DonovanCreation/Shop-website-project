<?php
require_once 'init.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: index.php');
        exit;
    } else {
        $error = t('invalid_login');
    }
}
?>
<!DOCTYPE html>
<html lang="<?= getLang() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ShopZone – Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="login-page">
  <div class="login-bg"></div>

  <div class="login-left">
    <div class="login-brand">
      <div class="brand-icon">🛍️</div>
      <h1>Shop<span>Zone</span></h1>
      <p class="login-tagline">Your ultimate marketplace experience</p>
    </div>

    <div class="login-features">
      <div class="feature-item">
        <div class="feature-icon">🚀</div>
        <span>Lightning-fast delivery with top couriers</span>
      </div>
      <div class="feature-item">
        <div class="feature-icon">💳</div>
        <span>Secure payments — card, PayPal, crypto & more</span>
      </div>
      <div class="feature-item">
        <div class="feature-icon">🛒</div>
        <span>Millions of products across every category</span>
      </div>
      <div class="feature-item">
        <div class="feature-icon">🏪</div>
        <span>Start selling in minutes with seller tools</span>
      </div>
    </div>
  </div>

  <div class="login-right">
    <div class="login-form-wrap">
      <h2><?= t('sign_in_to') ?> ShopZone</h2>
      <p><?= t('welcome') ?>! Please sign in to continue.</p>

      <?php if (isset($error)): ?>
        <div class="flash flash-error">
          <span class="flash-icon">✕</span><?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label class="form-label"><?= t('username') ?></label>
          <input type="text" name="username" class="form-control"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                 placeholder="Enter your username" required autocomplete="username">
        </div>
        <div class="form-group">
          <label class="form-label"><?= t('password') ?></label>
          <input type="password" name="password" class="form-control"
                 placeholder="Enter your password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">
          🔑 <?= t('login') ?>
        </button>
      </form>

      <div class="demo-accounts">
        <h4>🧪 Demo Accounts — click to fill</h4>
        <div class="demo-item" data-user="seller" data-pass="seller123">
          <div class="demo-role">🏪 <span>Seller</span></div>
          <div class="demo-cred">seller / seller123</div>
        </div>
        <div class="demo-item" data-user="customer" data-pass="customer123">
          <div class="demo-role">🛒 <span>Customer</span></div>
          <div class="demo-cred">customer / customer123</div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="script.js"></script>
</body>
</html>

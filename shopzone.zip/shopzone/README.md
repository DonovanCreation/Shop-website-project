# 🛍️ ShopZone — Full PHP Marketplace

A complete e-commerce platform with Seller & Customer interfaces, similar to eBay, Amazon, and Temu.

## 🚀 Quick Start

### Requirements
- PHP 7.4+ with PDO SQLite extension
- A web server (Apache, Nginx, or PHP's built-in server)

### Run Locally
```bash
# Navigate to the shopzone folder
cd shopzone

# Start the built-in PHP server
php -S localhost:8000

# Open in browser
open http://localhost:8000
```

### File Permissions
```bash
# Make uploads directory writable
chmod 755 uploads/
```

---

## 🔐 Demo Accounts

| Role     | Username   | Password     |
|----------|------------|--------------|
| Seller   | `seller`   | `seller123`  |
| Customer | `customer` | `customer123` |

---

## 🏪 Seller Features
- **Dashboard** with stats (products, orders, revenue)
- **Product Listings** — view, search, filter all products
- **Add/Edit Products** — with image upload (JPG, PNG, GIF, WebP)
- **Order Management** — view customer orders, update status (Pending → Processing → Shipped → Delivered)

## 🛒 Customer Features
- **Shop** — browse all products with category filters and sorting
- **Cart** — add items, adjust quantities, live price updates
- **Checkout** — full flow with:
  - Shipping address form
  - Payment methods: Credit Card, PayPal, Cryptocurrency, Cash on Delivery
  - Delivery services: FedEx Standard, FedEx Express, UPS Ground, UPS Express, DHL Express, USPS Priority, Free Shipping
- **Order History** — track all past orders

## ⚙️ Settings Features
- **Language switcher**: English, Bahasa Indonesia, 日本語, 한국어
- **Account info** display
- **Logout** with confirmation

---

## 📁 File Structure

```
shopzone/
├── index.php           # Entry point (redirects by role)
├── login.php           # Login page
├── logout.php          # Logout handler
├── init.php            # DB setup, session, helpers
├── lang.php            # Translations (EN, ID, JA, KO)
├── layout.php          # Shared header/sidebar/topbar
├── seller.php          # Seller dashboard
├── product_add.php     # Add/Edit product
├── seller_orders.php   # Seller order management
├── shop.php            # Customer shop/browse
├── cart.php            # Shopping cart
├── checkout.php        # Checkout (address, payment, delivery)
├── order_confirm.php   # Order confirmation
├── customer_orders.php # Customer order history
├── settings.php        # Settings + language
├── style.css           # Global styles
├── script.js           # JavaScript
├── shopzone.db         # SQLite database (auto-created)
└── uploads/            # Product images (writable)
```

---

## 🎨 Design
- **Font**: Outfit (headings) + Nunito (body)
- **Colors**: Deep Navy (#1a1a2e) + Vibrant Orange-Red (#FF4500)
- **Features**: Responsive sidebar, animated cards, live cart updates, drag-and-drop image upload

<?php
require_once 'layout.php';
requireRole('seller');

$db = getDB();
$sellerId = $_SESSION['user_id'];

// Update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $validStatuses = ['pending', 'processing', 'shipped', 'delivered'];
    if (in_array($status, $validStatuses)) {
        $db->prepare("UPDATE orders SET status=? WHERE id=?")->execute([$status, $orderId]);
        setFlash('success', 'Order status updated!');
    }
    header('Location: seller_orders.php');
    exit;
}

// Get orders that contain this seller's products
$orders = $db->prepare("
    SELECT DISTINCT o.*, u.username as customer_name
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON o.customer_id = u.id
    WHERE p.seller_id = ?
    ORDER BY o.created_at DESC
")->execute([$sellerId]);

$stmt = $db->prepare("
    SELECT DISTINCT o.*, u.username as customer_name
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    JOIN users u ON o.customer_id = u.id
    WHERE p.seller_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$sellerId]);
$orders = $stmt->fetchAll();

renderHead(t('seller_orders'));
renderSidebar('orders');
renderTopbar('🧾 ' . t('seller_orders'));
renderFlash();
?>

<div class="card fade-in">
  <div class="card-header">
    <h2>🧾 <?= t('seller_orders') ?></h2>
    <span class="badge badge-processing"><?= count($orders) ?> orders</span>
  </div>

  <?php if (empty($orders)): ?>
    <div class="empty-state">
      <div class="empty-icon">📋</div>
      <div class="empty-title"><?= t('no_orders') ?></div>
      <div class="empty-sub">Orders from customers will appear here.</div>
    </div>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th><?= t('order_id') ?></th>
            <th>Customer</th>
            <th>Items (Yours)</th>
            <th><?= t('total') ?></th>
            <th>Delivery</th>
            <th>Payment</th>
            <th><?= t('date') ?></th>
            <th><?= t('order_status') ?></th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $order):
            // Get items from this seller for this order
            $istmt = $db->prepare("
                SELECT oi.*, p.name as pname
                FROM order_items oi
                JOIN products p ON oi.product_id = p.id
                WHERE oi.order_id = ? AND p.seller_id = ?
            ");
            $istmt->execute([$order['id'], $sellerId]);
            $items = $istmt->fetchAll();
            $statusClass = 'badge-' . $order['status'];
          ?>
          <tr>
            <td><strong>#<?= $order['id'] ?></strong></td>
            <td>👤 <?= htmlspecialchars($order['customer_name']) ?></td>
            <td>
              <?php foreach ($items as $item): ?>
                <div style="font-size:12px">
                  <?= htmlspecialchars($item['pname']) ?>
                  <span style="color:var(--text-light)">x<?= $item['quantity'] ?></span>
                </div>
              <?php endforeach; ?>
            </td>
            <td><strong>$<?= number_format($order['total'], 2) ?></strong></td>
            <td><?= htmlspecialchars($order['delivery_service'] ?? '—') ?></td>
            <td><?= htmlspecialchars($order['payment_method'] ?? '—') ?></td>
            <td><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
            <td><span class="badge <?= $statusClass ?>"><?= t($order['status']) ?></span></td>
            <td>
              <form method="POST" style="display:flex;gap:6px;align-items:center">
                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                <select name="status" class="status-select">
                  <?php foreach (['pending','processing','shipped','delivered'] as $s): ?>
                    <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= t($s) ?></option>
                  <?php endforeach; ?>
                </select>
                <button type="submit" name="update_status" value="1" class="btn btn-sm btn-success">✓</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<?php renderFooter(); ?>

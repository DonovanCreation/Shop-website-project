<?php
require_once 'layout.php';
requireLogin();

// Handle language change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_lang'])) {
    $lang = $_POST['lang'] ?? 'en';
    $validLangs = ['en', 'id', 'ja', 'ko'];
    if (in_array($lang, $validLangs)) {
        $_SESSION['lang'] = $lang;
    }
    header('Location: settings.php');
    exit;
}

$user = getCurrentUser();
$role = $_SESSION['role'];
$currentLang = getLang();

$languages = [
    'en' => ['name' => 'English', 'flag' => '🇺🇸', 'native' => 'English'],
    'id' => ['name' => 'Bahasa Indonesia', 'flag' => '🇮🇩', 'native' => 'Bahasa'],
    'ja' => ['name' => 'Japanese', 'flag' => '🇯🇵', 'native' => '日本語'],
    'ko' => ['name' => 'Korean', 'flag' => '🇰🇷', 'native' => '한국어'],
];

renderHead(t('settings'));
renderSidebar('settings');
renderTopbar('⚙️ ' . t('settings'));
renderFlash();
?>

<div class="settings-grid fade-in">

  <!-- Account Info -->
  <div class="settings-section">
    <div class="settings-section-header">
      👤 Account Information
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label"><?= t('username') ?></div>
        <div class="settings-item-sub"><?= htmlspecialchars($user['username']) ?></div>
      </div>
      <span class="badge badge-processing"><?= ucfirst($role) ?></span>
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label">Role</div>
        <div class="settings-item-sub"><?= $role === 'seller' ? '🏪 Marketplace Seller' : '🛒 Customer' ?></div>
      </div>
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label">Member Since</div>
        <div class="settings-item-sub"><?= date('F Y', strtotime($user['created_at'])) ?></div>
      </div>
    </div>
  </div>

  <!-- Language Settings -->
  <div class="settings-section">
    <div class="settings-section-header">
      🌐 <?= t('language') ?>
    </div>
    <div style="padding:0">
      <form method="POST">
        <input type="hidden" name="set_lang" value="1">
        <div class="lang-options" style="padding:20px 24px">
          <?php foreach ($languages as $code => $lang): ?>
            <button type="submit" name="lang" value="<?= $code ?>"
                    class="lang-btn <?= $currentLang === $code ? 'active' : '' ?>">
              <?= $lang['flag'] ?> <?= $lang['native'] ?>
            </button>
          <?php endforeach; ?>
        </div>
        <div style="padding:0 24px 16px;font-size:13px;color:var(--text-light)">
          Currently: <strong><?= $languages[$currentLang]['flag'] ?> <?= $languages[$currentLang]['name'] ?></strong>
        </div>
      </form>
    </div>
  </div>

  <!-- Preferences -->
  <div class="settings-section">
    <div class="settings-section-header">
      🎨 Preferences
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label">Currency</div>
        <div class="settings-item-sub">US Dollar (USD)</div>
      </div>
      <span class="badge badge-success">Active</span>
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label">Email Notifications</div>
        <div class="settings-item-sub">Order updates & promotions</div>
      </div>
      <label style="display:flex;align-items:center;cursor:pointer">
        <input type="checkbox" checked style="accent-color:var(--primary);width:16px;height:16px">
      </label>
    </div>
    <div class="settings-item">
      <div>
        <div class="settings-item-label">Two-Factor Authentication</div>
        <div class="settings-item-sub">Add extra account security</div>
      </div>
      <span class="badge badge-pending">Off</span>
    </div>
  </div>

  <!-- Quick Links -->
  <div class="settings-section">
    <div class="settings-section-header">
      🔗 Quick Links
    </div>
    <?php if ($role === 'seller'): ?>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='seller.php'">
      <div>
        <div class="settings-item-label">📦 My Products</div>
        <div class="settings-item-sub">View and manage your listings</div>
      </div>
      <span>→</span>
    </div>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='product_add.php'">
      <div>
        <div class="settings-item-label">➕ Add New Product</div>
        <div class="settings-item-sub">List a new item for sale</div>
      </div>
      <span>→</span>
    </div>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='seller_orders.php'">
      <div>
        <div class="settings-item-label">🧾 Orders</div>
        <div class="settings-item-sub">View customer orders</div>
      </div>
      <span>→</span>
    </div>
    <?php else: ?>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='shop.php'">
      <div>
        <div class="settings-item-label">🛍️ Shop</div>
        <div class="settings-item-sub">Browse all products</div>
      </div>
      <span>→</span>
    </div>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='cart.php'">
      <div>
        <div class="settings-item-label">🛒 My Cart</div>
        <div class="settings-item-sub">View items in cart</div>
      </div>
      <span>→</span>
    </div>
    <div class="settings-item" style="cursor:pointer" onclick="window.location='customer_orders.php'">
      <div>
        <div class="settings-item-label">📋 My Orders</div>
        <div class="settings-item-sub">Track your orders</div>
      </div>
      <span>→</span>
    </div>
    <?php endif; ?>
  </div>

</div>

<!-- Logout Section -->
<div class="card fade-in" style="margin-top:20px;border:2px solid #fee2e2">
  <div style="padding:24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
    <div>
      <div style="font-weight:700;font-size:16px;color:#dc2626">⚠️ Sign Out</div>
      <div style="font-size:13px;color:var(--text-light);margin-top:4px">
        You're signed in as <strong><?= htmlspecialchars($user['username']) ?></strong>. Click to logout.
      </div>
    </div>
    <a href="logout.php" class="btn btn-danger btn-lg"
       onclick="return confirm('Are you sure you want to log out?')">
      🚪 <?= t('logout') ?>
    </a>
  </div>
</div>

<?php renderFooter(); ?>

<?php
require_once 'layout.php';
requireRole('customer');

$db     = getDB();
$custId = $_SESSION['user_id'];

// Get cart items using db_product
$st = $db->prepare("
    SELECT c.*, c.id AS cart_id, c.quantity,
           p.id AS product_id, p.name, p.price_usd AS price, p.stock, p.image, p.category
    FROM cart c JOIN db_product p ON c.product_id=p.id
    WHERE c.customer_id=?
");
$st->execute([$custId]);
$cartItems = $st->fetchAll();
if (empty($cartItems)) { header('Location: cart.php'); exit; }

$subtotalUSD = 0;
foreach ($cartItems as $i) $subtotalUSD += $i['price'] * $i['quantity'];

// Delivery services based on user's country setting
$deliveryServices  = getDeliveryServices();
$userCountry       = getCountry();

$paymentMethods = [
    'credit_card' => ['label'=>t('credit_card'), 'icon'=>'💳'],
    'paypal'      => ['label'=>t('paypal'),       'icon'=>'🅿️'],
    'crypto'      => ['label'=>t('crypto'),       'icon'=>'₿'],
    'cod'         => ['label'=>t('cod'),           'icon'=>'💵'],
];

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName  = trim($_POST['full_name']    ?? '');
    $address   = trim($_POST['address']      ?? '');
    $city      = trim($_POST['city']         ?? '');
    $postal    = trim($_POST['postal_code']  ?? '');
    $country   = trim($_POST['country_ship'] ?? '');
    $payment   = $_POST['payment_method']    ?? '';
    $delivery  = $_POST['delivery_service']  ?? '';

    if (!$fullName)  $errors[] = 'Full name is required.';
    if (!$address)   $errors[] = 'Address is required.';
    if (!$city)      $errors[] = 'City is required.';
    if (!$postal)    $errors[] = 'Postal code is required.';
    if (!$country)   $errors[] = 'Country is required.';
    if (!$payment)   $errors[] = 'Please select a payment method.';
    if (!isset($deliveryServices[$delivery])) $errors[] = 'Please select a delivery service.';

    if (empty($errors)) {
        $ds           = $deliveryServices[$delivery];
        $deliveryCost = $ds['price'];
        $totalUSD     = $subtotalUSD + $deliveryCost;
        $currency     = getCurrency();
        $totalLocal   = convertPrice($totalUSD);

        $db->prepare("
            INSERT INTO orders (customer_id, total_usd, currency, total_local, address, city, postal_code, country, payment_method, delivery_service, delivery_cost_usd, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,'processing')
        ")->execute([$custId, $totalUSD, $currency, $totalLocal, "$fullName, $address", $city, $postal, $country, $payment, $ds['name'], $deliveryCost]);
        $orderId = $db->lastInsertId();

        foreach ($cartItems as $item) {
            $db->prepare("INSERT INTO order_items (order_id,product_id,product_name,quantity,price_usd) VALUES (?,?,?,?,?)")
               ->execute([$orderId, $item['product_id'], $item['name'], $item['quantity'], $item['price']]);
            $db->prepare("UPDATE db_product SET stock=GREATEST(0,stock-?) WHERE id=?")->execute([$item['quantity'], $item['product_id']]);
        }
        $db->prepare("DELETE FROM cart WHERE customer_id=?")->execute([$custId]);

        header("Location: order_confirm.php?id={$orderId}"); exit;
    }
}

$selDelivery = $_POST['delivery_service'] ?? array_key_first($deliveryServices);
$selPayment  = $_POST['payment_method']  ?? 'credit_card';
$delivCostUSD = $deliveryServices[$selDelivery]['price'] ?? 0;
$totalUSD    = $subtotalUSD + $delivCostUSD;

renderHead(t('checkout'));
renderSidebar('cart');
renderTopbar('🚀 ' . t('checkout'), false, true);
renderFlash();
?>

<div class="checkout-steps fade-in">
  <div class="step done"><div class="step-num">✓</div><span>Cart</span></div>
  <div class="step-divider"></div>
  <div class="step active"><div class="step-num">2</div><span><?= t('shipping_address') ?></span></div>
  <div class="step-divider"></div>
  <div class="step"><div class="step-num">3</div><span><?= t('payment_method') ?></span></div>
  <div class="step-divider"></div>
  <div class="step"><div class="step-num">4</div><span>Confirm</span></div>
</div>

<form method="POST" id="checkout-form">
<div class="checkout-layout fade-in">
  <div style="display:flex;flex-direction:column;gap:20px">

    <!-- Shipping Address -->
    <div class="card">
      <div class="card-header"><h2>📍 <?= t('shipping_address') ?></h2></div>
      <div class="card-body">
        <?php if ($errors): ?>
          <div class="flash flash-error"><span class="flash-icon">✕</span><div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div></div>
        <?php endif; ?>
        <div class="form-group">
          <label class="form-label">👤 <?= t('full_name') ?> *</label>
          <input type="text" name="full_name" class="form-control" required
                 value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" placeholder="John Doe">
        </div>
        <div class="form-group">
          <label class="form-label">🏠 <?= t('address') ?> *</label>
          <input type="text" name="address" class="form-control" required
                 value="<?= htmlspecialchars($_POST['address'] ?? '') ?>" placeholder="123 Main Street, Apt 4B">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">🌆 <?= t('city') ?> *</label>
            <input type="text" name="city" class="form-control" required
                   value="<?= htmlspecialchars($_POST['city'] ?? '') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">📮 <?= t('postal_code') ?> *</label>
            <input type="text" name="postal_code" class="form-control" required
                   value="<?= htmlspecialchars($_POST['postal_code'] ?? '') ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🌍 <?= t('country') ?> *</label>
          <select name="country_ship" class="form-control" required>
            <option value="">Select country...</option>
            <?php foreach (['United States','Japan','China','South Korea','Indonesia','Canada','United Kingdom','Australia','Germany','France','Singapore','Malaysia','Thailand','Philippines','India','Brazil'] as $c): ?>
              <option value="<?= $c ?>" <?= ($_POST['country_ship'] ?? '') === $c ? 'selected' : '' ?>><?= $c ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
    </div>

    <!-- Payment Method -->
    <div class="card">
      <div class="card-header"><h2>💳 <?= t('payment_method') ?></h2></div>
      <div class="card-body">
        <div class="payment-options">
          <?php foreach ($paymentMethods as $key => $pm): ?>
            <label class="payment-option <?= $selPayment===$key?'selected':'' ?>">
              <input type="radio" name="payment_method" value="<?= $key ?>" <?= $selPayment===$key?'checked':'' ?> required>
              <div class="payment-icon"><?= $pm['icon'] ?></div>
              <div class="payment-label"><?= $pm['label'] ?></div>
            </label>
          <?php endforeach; ?>
        </div>
        <div id="card-fields" style="margin-top:16px;<?= $selPayment!=='credit_card'?'display:none':'' ?>">
          <div class="form-group">
            <label class="form-label">Card Number</label>
            <input type="text" class="form-control" placeholder="•••• •••• •••• ••••" maxlength="19">
          </div>
          <div class="form-row">
            <div class="form-group"><label class="form-label">Expiry</label><input type="text" class="form-control" placeholder="MM/YY"></div>
            <div class="form-group"><label class="form-label">CVV</label><input type="text" class="form-control" placeholder="•••"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Delivery Service (country-specific) -->
    <div class="card">
      <div class="card-header">
        <h2>🚚 <?= t('delivery_service') ?></h2>
        <span class="badge badge-processing"><?= COUNTRY_DEFAULTS[$userCountry]['flag'] ?? '' ?> <?= $userCountry ?></span>
      </div>
      <div class="card-body">
        <p style="font-size:13px;color:var(--text-light);margin-bottom:14px">
          Showing delivery options for <strong><?= $userCountry ?></strong>. Change in
          <a href="settings.php" style="color:var(--primary)">Settings</a>.
        </p>
        <div class="delivery-options">
          <?php foreach ($deliveryServices as $key => $ds): ?>
            <label class="delivery-option <?= $selDelivery===$key?'selected':'' ?>">
              <input type="radio" name="delivery_service" value="<?= $key ?>"
                     <?= $selDelivery===$key?'checked':'' ?> required
                     onchange="updateDeliveryTotal(<?= $ds['price'] ?>)">
              <div class="delivery-logo"><?= $ds['logo'] ?></div>
              <div class="delivery-info">
                <div class="delivery-name"><?= htmlspecialchars($ds['name']) ?></div>
                <div class="delivery-time">🕐 <?= $ds['time'] ?></div>
              </div>
              <div class="delivery-price"><?= $ds['price']==0 ? 'FREE' : formatPrice($ds['price']) ?></div>
            </label>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- Order Summary -->
  <div>
    <div class="order-summary" style="position:sticky;top:80px">
      <h3>📋 <?= t('checkout') ?> Summary</h3>
      <?php foreach ($cartItems as $item): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--border)">
          <div style="width:40px;height:40px;border-radius:8px;background:var(--bg);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">
            <?= productImage($item) ?>
          </div>
          <div style="flex:1;font-size:13px">
            <div style="font-weight:600"><?= htmlspecialchars($item['name']) ?></div>
            <div style="color:var(--text-light)">×<?= $item['quantity'] ?></div>
          </div>
          <div style="font-weight:700;font-size:14px"><?= formatPrice($item['price'] * $item['quantity']) ?></div>
        </div>
      <?php endforeach; ?>
      <div class="summary-row" style="margin-top:8px"><span>Subtotal</span><span><?= formatPrice($subtotalUSD) ?></span></div>
      <div class="summary-row"><span><?= t('shipping_fee') ?></span><span id="delivery-cost"><?= $delivCostUSD==0?'FREE':formatPrice($delivCostUSD) ?></span></div>
      <div class="summary-total">
        <span><?= t('order_total') ?></span>
        <span id="order-total" style="color:var(--primary)"><?= formatPrice($totalUSD) ?></span>
      </div>
      <br>
      <button type="submit" class="btn btn-primary btn-block btn-lg">✅ <?= t('place_order') ?></button>
      <a href="cart.php" class="btn btn-outline btn-block" style="margin-top:10px;justify-content:center;display:flex">← <?= t('cart') ?></a>
    </div>
  </div>
</div>
</form>

<script>
const subtotalUSD  = <?= $subtotalUSD ?>;
const rate         = <?= CURRENCY_RATES[getCurrency()]['rate'] ?>;
const decimals     = <?= CURRENCY_RATES[getCurrency()]['decimals'] ?>;
const symbol       = '<?= addslashes(CURRENCY_RATES[getCurrency()]['symbol']) ?>';
const curCode      = '<?= getCurrency() ?>';

function fmtPrice(usd) {
    const local = usd * rate;
    const fmt   = local.toFixed(decimals).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    if (curCode === 'IDR') return symbol + ' ' + fmt;
    if (curCode === 'CNY') return symbol + fmt + ' 元';
    return symbol + fmt;
}

function updateDeliveryTotal(priceUSD) {
    const total = subtotalUSD + priceUSD;
    document.getElementById('delivery-cost').textContent = priceUSD === 0 ? 'FREE' : fmtPrice(priceUSD);
    document.getElementById('order-total').textContent   = fmtPrice(total);
    document.querySelectorAll('.delivery-option').forEach(o => o.classList.remove('selected'));
    event.target?.closest('.delivery-option')?.classList.add('selected');
}

document.querySelectorAll('input[name="payment_method"]').forEach(r => {
    r.addEventListener('change', function () {
        document.getElementById('card-fields').style.display = this.value === 'credit_card' ? 'block' : 'none';
    });
});
</script>

<?php renderFooter(); ?>

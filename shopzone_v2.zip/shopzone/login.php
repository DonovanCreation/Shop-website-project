<?php
require_once 'init.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $db = getDB();
    $st = $db->prepare("SELECT * FROM db_account WHERE username = ?");
    $st->execute([$username]);
    $user = $st->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id']  = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role']     = $user['role'];
        syncSessionPrefs($user);
        header('Location: index.php');
        exit;
    }
    $error = t('invalid_login');
}
?>
<!DOCTYPE html>
<html lang="<?= getLang() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ShopZone – Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="login-page">
  <div class="login-bg"></div>

  <div class="login-left">
    <div class="login-brand">
      <div class="brand-icon">🛍️</div>
      <h1>Shop<span>Zone</span></h1>
      <p class="login-tagline">Your global marketplace experience</p>
    </div>
    <div class="login-features">
      <div class="feature-item"><div class="feature-icon">🌏</div><span>5 countries · 5 currencies supported</span></div>
      <div class="feature-item"><div class="feature-icon">🚚</div><span>Local couriers: FedEx, Yamato, JNE & more</span></div>
      <div class="feature-item"><div class="feature-icon">💳</div><span>Secure payments — card, PayPal, crypto & COD</span></div>
      <div class="feature-item"><div class="feature-icon">🌐</div><span>5 languages: EN · 中文 · 日本語 · 한국어 · Bahasa</span></div>
    </div>
  </div>

  <div class="login-right">
    <div class="login-form-wrap">
      <h2><?= t('sign_in_to') ?> ShopZone</h2>
      <p><?= t('welcome') ?>! <?= t('no_account') ?> <a href="register.php" style="color:var(--primary);font-weight:700"><?= t('register') ?></a></p>

      <?php if ($error): ?>
        <div class="flash flash-error"><span class="flash-icon">✕</span><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="POST">
        <div class="form-group">
          <label class="form-label"><?= t('username') ?></label>
          <input type="text" name="username" class="form-control"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                 placeholder="Enter your username" required autocomplete="username">
        </div>
        <div class="form-group">
          <label class="form-label"><?= t('password') ?></label>
          <input type="password" name="password" class="form-control"
                 placeholder="Enter your password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block btn-lg">🔑 <?= t('login') ?></button>
      </form>

      <div class="demo-accounts">
        <h4>🧪 Demo Accounts — click to fill</h4>
        <div class="demo-item" data-user="seller" data-pass="seller123">
          <div class="demo-role">🏪 <span>Seller</span></div>
          <div class="demo-cred">seller / seller123</div>
        </div>
        <div class="demo-item" data-user="customer" data-pass="customer123">
          <div class="demo-role">🛒 <span>Customer</span></div>
          <div class="demo-cred">customer / customer123</div>
        </div>
      </div>

      <p style="text-align:center;margin-top:20px;font-size:13px;color:var(--text-light)">
        <?= t('no_account') ?> <a href="register.php" style="color:var(--primary);font-weight:700"><?= t('create_account') ?></a>
      </p>
    </div>
  </div>
</div>
<script src="script.js"></script>
</body>
</html>

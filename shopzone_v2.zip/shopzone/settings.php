<?php
require_once 'layout.php';
requireLogin();

$user = getCurrentUser();
$role = $_SESSION['role'];
$db   = getDB();

// ── Save settings ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $lang     = $_POST['language'] ?? 'en';
    $country  = $_POST['country']  ?? 'USA';
    $currency = $_POST['currency'] ?? 'USD';

    $validLangs      = ['en','id','ja','ko','zh'];
    $validCountries  = array_keys(COUNTRY_DEFAULTS);
    $validCurrencies = array_keys(CURRENCY_RATES);

    if (!in_array($lang, $validLangs))          $lang    = 'en';
    if (!in_array($country, $validCountries))    $country = 'USA';
    if (!in_array($currency, $validCurrencies))  $currency= 'USD';

    // Update db_account
    $db->prepare("UPDATE db_account SET language=?, country=?, currency=? WHERE id=?")
       ->execute([$lang, $country, $currency, $_SESSION['user_id']]);

    // Sync session
    $_SESSION['prefs']['language'] = $lang;
    $_SESSION['prefs']['country']  = $country;
    $_SESSION['prefs']['currency'] = $currency;

    setFlash('success', t('settings_saved'));
    header('Location: settings.php');
    exit;
}

$currentLang     = getLang();
$currentCountry  = getCountry();
$currentCurrency = getCurrency();

$languages = [
    'en' => ['name'=>'English',          'flag'=>'🇺🇸','native'=>'English'],
    'zh' => ['name'=>'Chinese',          'flag'=>'🇨🇳','native'=>'中文'],
    'ja' => ['name'=>'Japanese',         'flag'=>'🇯🇵','native'=>'日本語'],
    'ko' => ['name'=>'Korean',           'flag'=>'🇰🇷','native'=>'한국어'],
    'id' => ['name'=>'Bahasa Indonesia', 'flag'=>'🇮🇩','native'=>'Bahasa'],
];

renderHead(t('settings'));
renderSidebar('settings');
renderTopbar('⚙️ ' . t('settings'));
renderFlash();
?>

<form method="POST">
<div class="settings-grid fade-in">

  <!-- ── Account Info ──────────────────────────────────────── -->
  <div class="settings-section">
    <div class="settings-section-header">👤 <?= t('account_settings') ?></div>
    <div class="settings-item">
      <div><div class="settings-item-label"><?= t('username') ?></div>
        <div class="settings-item-sub"><?= htmlspecialchars($user['username']) ?></div></div>
      <span class="badge badge-processing"><?= ucfirst($role) ?></span>
    </div>
    <div class="settings-item">
      <div><div class="settings-item-label"><?= t('email') ?></div>
        <div class="settings-item-sub"><?= htmlspecialchars($user['email'] ?? '—') ?></div></div>
    </div>
    <div class="settings-item">
      <div><div class="settings-item-label">Member Since</div>
        <div class="settings-item-sub"><?= date('F j, Y', strtotime($user['created_at'])) ?></div></div>
    </div>
  </div>

  <!-- ── Language ──────────────────────────────────────────── -->
  <div class="settings-section">
    <div class="settings-section-header">🌐 <?= t('language') ?></div>
    <div class="lang-options" style="padding:20px 24px">
      <?php foreach ($languages as $code => $lng): ?>
        <button type="button"
                onclick="setLang('<?= $code ?>')"
                class="lang-btn <?= $currentLang === $code ? 'active' : '' ?>"
                id="lang-btn-<?= $code ?>">
          <?= $lng['flag'] ?> <?= $lng['native'] ?>
        </button>
      <?php endforeach; ?>
      <input type="hidden" name="language" id="lang-input" value="<?= $currentLang ?>">
    </div>
    <div style="padding:0 24px 16px;font-size:13px;color:var(--text-light)">
      Currently: <strong id="lang-display">
        <?= $languages[$currentLang]['flag'] ?> <?= $languages[$currentLang]['name'] ?>
      </strong>
    </div>
  </div>

  <!-- ── Country / Location ────────────────────────────────── -->
  <div class="settings-section" style="grid-column:1/-1">
    <div class="settings-section-header">🌍 <?= t('country_location') ?></div>
    <div style="padding:20px 24px">
      <div class="country-selector">
        <?php foreach (COUNTRY_DEFAULTS as $cname => $cdata): ?>
          <label class="country-option <?= $currentCountry === $cname ? 'selected' : '' ?>">
            <input type="radio" name="country" value="<?= $cname ?>"
                   <?= $currentCountry === $cname ? 'checked' : '' ?>
                   onchange="onCountryChange('<?= $cname ?>','<?= $cdata['currency'] ?>','<?= $cdata['language'] ?>')">
            <div class="country-flag-big"><?= $cdata['flag'] ?></div>
            <div class="country-name-label"><?= $cname ?></div>
            <div class="country-cur-label"><?= $cdata['currency'] ?></div>
          </label>
        <?php endforeach; ?>
      </div>
      <div class="country-preview-strip" id="country-preview-strip">
        📍 Country: <strong id="cps-country"><?= $currentCountry ?></strong> ·
        💰 Currency auto-set: <strong id="cps-currency"><?= $currentCurrency ?></strong> ·
        🌐 Language auto-set: <strong id="cps-lang"><?= $currentLang ?></strong>
      </div>
    </div>
  </div>

  <!-- ── Currency ──────────────────────────────────────────── -->
  <div class="settings-section" style="grid-column:1/-1">
    <div class="settings-section-header">💰 <?= t('currency') ?></div>
    <div style="padding:20px 24px">
      <p style="font-size:13px;color:var(--text-light);margin-bottom:16px">
        Currency is auto-set from your country, but you can override it below.
      </p>
      <div class="currency-grid">
        <?php foreach (CURRENCY_RATES as $code => $cinfo): ?>
          <label class="currency-option <?= $currentCurrency === $code ? 'selected' : '' ?>">
            <input type="radio" name="currency" value="<?= $code ?>"
                   <?= $currentCurrency === $code ? 'checked' : '' ?>
                   onchange="onCurrencyChange('<?= $code ?>')">
            <div class="cur-symbol"><?= $cinfo['symbol'] ?></div>
            <div class="cur-code"><?= $code ?></div>
            <div class="cur-name"><?= $cinfo['name'] ?></div>
            <div class="cur-rate">1 USD = <?= number_format($cinfo['rate'], $cinfo['decimals'] > 0 ? 2 : 0) ?> <?= $code ?></div>
          </label>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- ── Delivery Preview ──────────────────────────────────── -->
  <div class="settings-section" style="grid-column:1/-1">
    <div class="settings-section-header">🚚 <?= t('delivery_service') ?> Preview for <?= $currentCountry ?></div>
    <div style="padding:20px 24px">
      <div style="display:flex;flex-wrap:wrap;gap:10px">
        <?php foreach (getDeliveryServices() as $key => $ds): ?>
          <div style="background:var(--bg);border-radius:10px;padding:12px 16px;font-size:13px;display:flex;align-items:center;gap:10px;border:1px solid var(--border)">
            <span style="font-size:20px"><?= $ds['logo'] ?></span>
            <div>
              <div style="font-weight:700"><?= htmlspecialchars($ds['name']) ?></div>
              <div style="color:var(--text-light);font-size:11px"><?= $ds['time'] ?> · <?= $ds['price'] == 0 ? 'FREE' : formatPrice($ds['price']) ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- ── Quick Links ───────────────────────────────────────── -->
  <div class="settings-section">
    <div class="settings-section-header">🔗 Quick Links</div>
    <?php if ($role === 'seller'): ?>
      <div class="settings-item" style="cursor:pointer" onclick="location='seller.php'">
        <div><div class="settings-item-label">📦 <?= t('my_products') ?></div></div><span>→</span>
      </div>
      <div class="settings-item" style="cursor:pointer" onclick="location='product_add.php'">
        <div><div class="settings-item-label">➕ <?= t('add_product') ?></div></div><span>→</span>
      </div>
      <div class="settings-item" style="cursor:pointer" onclick="location='seller_orders.php'">
        <div><div class="settings-item-label">🧾 <?= t('seller_orders') ?></div></div><span>→</span>
      </div>
    <?php else: ?>
      <div class="settings-item" style="cursor:pointer" onclick="location='shop.php'">
        <div><div class="settings-item-label">🛍️ <?= t('shop') ?></div></div><span>→</span>
      </div>
      <div class="settings-item" style="cursor:pointer" onclick="location='cart.php'">
        <div><div class="settings-item-label">🛒 <?= t('cart') ?></div></div><span>→</span>
      </div>
      <div class="settings-item" style="cursor:pointer" onclick="location='customer_orders.php'">
        <div><div class="settings-item-label">📋 <?= t('orders') ?></div></div><span>→</span>
      </div>
    <?php endif; ?>
  </div>

</div><!-- /settings-grid -->

<!-- Save + Logout row -->
<div style="display:flex;gap:16px;margin-top:20px;flex-wrap:wrap">
  <button type="submit" name="save_settings" value="1" class="btn btn-primary btn-lg">
    💾 <?= t('save_settings') ?>
  </button>
  <a href="logout.php" class="btn btn-danger btn-lg"
     onclick="return confirm('<?= t('logout') ?>?')">
    🚪 <?= t('logout') ?>
  </a>
</div>

</form>

<script>
// Language selector
function setLang(code) {
    document.getElementById('lang-input').value = code;
    const names = <?= json_encode(array_map(fn($l)=>$l['flag'].' '.$l['name'], $languages)) ?>;
    document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('lang-btn-' + code)?.classList.add('active');
    document.getElementById('lang-display').textContent = names[code] || code;
}

// Country change → auto-set currency & language
function onCountryChange(country, currency, lang) {
    document.getElementById('cps-country').textContent  = country;
    document.getElementById('cps-currency').textContent = currency;
    document.getElementById('cps-lang').textContent     = lang;
    // Auto-set currency radio
    const cr = document.querySelector('input[name="currency"][value="' + currency + '"]');
    if (cr) { cr.checked = true; onCurrencyChange(currency); }
    // Auto-set language
    setLang(lang);

    document.querySelectorAll('.country-option').forEach(o => o.classList.remove('selected'));
    const radio = document.querySelector('input[name="country"][value="' + country + '"]');
    if (radio) radio.closest('.country-option').classList.add('selected');
}

function onCurrencyChange(code) {
    document.querySelectorAll('.currency-option').forEach(o => o.classList.remove('selected'));
    const radio = document.querySelector('input[name="currency"][value="' + code + '"]');
    if (radio) radio.closest('.currency-option').classList.add('selected');
}

// Payment options
document.querySelectorAll('.currency-option, .country-option').forEach(opt => {
    opt.addEventListener('click', function () {
        this.closest('.currency-grid, .country-selector')
            ?.querySelectorAll('.currency-option, .country-option')
            .forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
    });
});
</script>

<?php renderFooter(); ?>

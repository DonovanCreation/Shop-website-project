<?php
require_once 'init.php';
if (isLoggedIn()) { header('Location: index.php'); exit; }

$errors = [];
$formData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username  = trim($_POST['username']  ?? '');
    $email     = trim($_POST['email']     ?? '');
    $password  = $_POST['password']       ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';
    $role      = $_POST['role']           ?? 'customer';
    $fullName  = trim($_POST['full_name'] ?? '');
    $country   = $_POST['country']        ?? 'USA';
    $language  = COUNTRY_DEFAULTS[$country]['language'] ?? 'en';
    $currency  = COUNTRY_DEFAULTS[$country]['currency'] ?? 'USD';

    $formData = compact('username','email','role','fullName','country');

    // Validation
    if (strlen($username) < 3)  $errors[] = 'Username must be at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($password) < 6)  $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = t('passwords_mismatch');
    if (!array_key_exists($country, COUNTRY_DEFAULTS)) $errors[] = 'Please select a valid country.';

    if (empty($errors)) {
        $db = getDB();
        // Check unique username
        $st = $db->prepare("SELECT id FROM db_account WHERE username = ?");
        $st->execute([$username]);
        if ($st->fetch()) $errors[] = t('username_taken');

        // Check unique email
        $st = $db->prepare("SELECT id FROM db_account WHERE email = ?");
        $st->execute([$email]);
        if ($st->fetch()) $errors[] = t('email_taken');
    }

    if (empty($errors)) {
        $db = getDB();
        $hashed = password_hash($password, PASSWORD_BCRYPT);
        $st = $db->prepare(
            "INSERT INTO db_account (username, password, email, role, full_name, country, currency, language)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $st->execute([$username, $hashed, $email, $role, $fullName, $country, $currency, $language]);

        setFlash('success', t('register_success'));
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="<?= getLang() ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ShopZone – <?= t('register') ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="login-page">
  <div class="login-bg"></div>

  <div class="login-left">
    <div class="login-brand">
      <div class="brand-icon">🛍️</div>
      <h1>Shop<span>Zone</span></h1>
      <p class="login-tagline"><?= t('create_account') ?></p>
    </div>
    <div class="login-features">
      <div class="feature-item"><div class="feature-icon">🌏</div><span>Choose your country & auto-set currency</span></div>
      <div class="feature-item"><div class="feature-icon">🏪</div><span>Register as Seller or Customer</span></div>
      <div class="feature-item"><div class="feature-icon">🔒</div><span>Your data is stored in db_account table</span></div>
      <div class="feature-item"><div class="feature-icon">🌐</div><span>Language auto-set from your country</span></div>
    </div>
  </div>

  <div class="login-right" style="overflow-y:auto">
    <div class="login-form-wrap">
      <h2>📝 <?= t('create_account') ?></h2>
      <p><?= t('already_have_account') ?> <a href="login.php" style="color:var(--primary);font-weight:700"><?= t('login') ?></a></p>

      <?php if ($errors): ?>
        <div class="flash flash-error">
          <span class="flash-icon">✕</span>
          <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
        </div>
      <?php endif; ?>

      <form method="POST">

        <!-- Role selector -->
        <div class="form-group">
          <label class="form-label">Account Type</label>
          <div class="role-selector">
            <label class="role-option <?= ($formData['role'] ?? 'customer') === 'customer' ? 'selected' : '' ?>">
              <input type="radio" name="role" value="customer" <?= ($formData['role'] ?? 'customer') === 'customer' ? 'checked' : '' ?>>
              <div class="role-icon">🛒</div>
              <div class="role-label">Customer</div>
              <div class="role-sub">Buy products</div>
            </label>
            <label class="role-option <?= ($formData['role'] ?? '') === 'seller' ? 'selected' : '' ?>">
              <input type="radio" name="role" value="seller" <?= ($formData['role'] ?? '') === 'seller' ? 'checked' : '' ?>>
              <div class="role-icon">🏪</div>
              <div class="role-label">Seller</div>
              <div class="role-sub">List & sell products</div>
            </label>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label"><?= t('full_name') ?></label>
            <input type="text" name="full_name" class="form-control"
                   value="<?= htmlspecialchars($formData['fullName'] ?? '') ?>"
                   placeholder="John Doe">
          </div>
          <div class="form-group">
            <label class="form-label"><?= t('username') ?> *</label>
            <input type="text" name="username" class="form-control" required
                   value="<?= htmlspecialchars($formData['username'] ?? '') ?>"
                   placeholder="username123">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label"><?= t('email') ?> *</label>
          <input type="email" name="email" class="form-control" required
                 value="<?= htmlspecialchars($formData['email'] ?? '') ?>"
                 placeholder="you@example.com">
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label"><?= t('password') ?> *</label>
            <input type="password" name="password" class="form-control" required
                   placeholder="Min 6 characters">
          </div>
          <div class="form-group">
            <label class="form-label"><?= t('confirm_password') ?> *</label>
            <input type="password" name="confirm_password" class="form-control" required
                   placeholder="Repeat password">
          </div>
        </div>

        <!-- Country selector — auto-sets currency & language -->
        <div class="form-group">
          <label class="form-label">🌍 <?= t('country_location') ?> *</label>
          <div class="country-selector">
            <?php foreach (COUNTRY_DEFAULTS as $cname => $cdata): ?>
              <label class="country-option <?= ($formData['country'] ?? 'USA') === $cname ? 'selected' : '' ?>">
                <input type="radio" name="country" value="<?= $cname ?>"
                       <?= ($formData['country'] ?? 'USA') === $cname ? 'checked' : '' ?>
                       onchange="updateCountryPreview('<?= $cname ?>','<?= $cdata['currency'] ?>','<?= $cdata['language'] ?>')">
                <div class="country-flag-big"><?= $cdata['flag'] ?></div>
                <div class="country-name-label"><?= $cname ?></div>
                <div class="country-cur-label"><?= $cdata['currency'] ?></div>
              </label>
            <?php endforeach; ?>
          </div>
          <div id="country-preview" class="country-preview-strip">
            🌐 Selected: <strong id="prev-country"><?= $formData['country'] ?? 'USA' ?></strong> ·
            Currency: <strong id="prev-currency"><?= COUNTRY_DEFAULTS[$formData['country'] ?? 'USA']['currency'] ?></strong> ·
            Language: <strong id="prev-lang"><?= COUNTRY_DEFAULTS[$formData['country'] ?? 'USA']['language'] ?></strong>
          </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block btn-lg">
          🚀 <?= t('create_account') ?>
        </button>
      </form>

      <p style="text-align:center;margin-top:16px;font-size:13px;color:var(--text-light)">
        <?= t('already_have_account') ?> <a href="login.php" style="color:var(--primary);font-weight:700"><?= t('login') ?></a>
      </p>
    </div>
  </div>
</div>

<script src="script.js"></script>
<script>
function updateCountryPreview(country, currency, lang) {
    document.getElementById('prev-country').textContent  = country;
    document.getElementById('prev-currency').textContent = currency;
    document.getElementById('prev-lang').textContent     = lang;

    // Highlight selected country option
    document.querySelectorAll('.country-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    const radio = document.querySelector('input[name="country"][value="' + country + '"]');
    if (radio) radio.closest('.country-option').classList.add('selected');
}

// Role selector visual
document.querySelectorAll('.role-option').forEach(opt => {
    opt.addEventListener('click', function () {
        document.querySelectorAll('.role-option').forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
    });
});
</script>
</body>
</html>

-- ============================================================
--  ShopZone Database Schema
--  Import this file into phpMyAdmin
--  Database: db_shopzone
-- ============================================================

CREATE DATABASE IF NOT EXISTS `db_shopzone`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `db_shopzone`;

-- ============================================================
--  TABLE: db_account  (all users: sellers + customers)
-- ============================================================
CREATE TABLE IF NOT EXISTS `db_account` (
  `id`          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `username`    VARCHAR(60)     NOT NULL,
  `password`    VARCHAR(255)    NOT NULL,
  `email`       VARCHAR(120)    DEFAULT NULL,
  `role`        ENUM('seller','customer') NOT NULL DEFAULT 'customer',
  `full_name`   VARCHAR(120)    DEFAULT NULL,
  `country`     VARCHAR(60)     DEFAULT 'USA',
  `currency`    VARCHAR(10)     DEFAULT 'USD',
  `language`    VARCHAR(10)     DEFAULT 'en',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`),
  UNIQUE KEY `uq_email`    (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLE: db_product  (all product listings)
-- ============================================================
CREATE TABLE IF NOT EXISTS `db_product` (
  `id`          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `seller_id`   INT UNSIGNED    NOT NULL,
  `name`        VARCHAR(255)    NOT NULL,
  `description` TEXT            DEFAULT NULL,
  `price_usd`   DECIMAL(12,2)   NOT NULL DEFAULT '0.00',
  `stock`       INT             NOT NULL DEFAULT 0,
  `category`    VARCHAR(60)     NOT NULL DEFAULT 'General',
  `image`       VARCHAR(255)    DEFAULT NULL,
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_seller`   (`seller_id`),
  KEY `idx_category` (`category`),
  CONSTRAINT `fk_product_seller` FOREIGN KEY (`seller_id`)
    REFERENCES `db_account` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLE: cart
-- ============================================================
CREATE TABLE IF NOT EXISTS `cart` (
  `id`          INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `customer_id` INT UNSIGNED    NOT NULL,
  `product_id`  INT UNSIGNED    NOT NULL,
  `quantity`    INT             NOT NULL DEFAULT 1,
  `added_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cart_item` (`customer_id`, `product_id`),
  CONSTRAINT `fk_cart_customer` FOREIGN KEY (`customer_id`)
    REFERENCES `db_account` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cart_product`  FOREIGN KEY (`product_id`)
    REFERENCES `db_product` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLE: orders
-- ============================================================
CREATE TABLE IF NOT EXISTS `orders` (
  `id`               INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `customer_id`      INT UNSIGNED   NOT NULL,
  `total_usd`        DECIMAL(12,2)  NOT NULL,
  `currency`         VARCHAR(10)    NOT NULL DEFAULT 'USD',
  `total_local`      DECIMAL(18,2)  NOT NULL,
  `address`          TEXT           DEFAULT NULL,
  `city`             VARCHAR(120)   DEFAULT NULL,
  `postal_code`      VARCHAR(30)    DEFAULT NULL,
  `country`          VARCHAR(60)    DEFAULT NULL,
  `payment_method`   VARCHAR(60)    DEFAULT NULL,
  `delivery_service` VARCHAR(120)   DEFAULT NULL,
  `delivery_cost_usd` DECIMAL(10,2) DEFAULT '0.00',
  `status`           ENUM('pending','processing','shipped','delivered') NOT NULL DEFAULT 'pending',
  `created_at`       DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_customer` (`customer_id`),
  CONSTRAINT `fk_order_customer` FOREIGN KEY (`customer_id`)
    REFERENCES `db_account` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLE: order_items
-- ============================================================
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`           INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `order_id`     INT UNSIGNED   NOT NULL,
  `product_id`   INT UNSIGNED   NOT NULL,
  `product_name` VARCHAR(255)   NOT NULL,
  `quantity`     INT            NOT NULL,
  `price_usd`    DECIMAL(12,2)  NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_oi_order`   (`order_id`),
  KEY `idx_oi_product` (`product_id`),
  CONSTRAINT `fk_oi_order`   FOREIGN KEY (`order_id`)
    REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_oi_product` FOREIGN KEY (`product_id`)
    REFERENCES `db_product` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  SEED: demo accounts  (passwords are hashed — see below)
--  seller   / seller123
--  customer / customer123
-- ============================================================
INSERT IGNORE INTO `db_account`
  (`username`, `password`, `email`, `role`, `full_name`, `country`, `currency`, `language`)
VALUES
  ('seller',
   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
   'seller@shopzone.demo', 'seller', 'Demo Seller', 'USA', 'USD', 'en'),
  ('customer',
   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
   'customer@shopzone.demo', 'customer', 'Demo Customer', 'USA', 'USD', 'en');

-- ============================================================
--  SEED: demo products
-- ============================================================
INSERT IGNORE INTO `db_product`
  (`seller_id`, `name`, `description`, `price_usd`, `stock`, `category`)
SELECT
  a.id,
  p.name, p.description, p.price_usd, p.stock, p.category
FROM `db_account` a
JOIN (
  SELECT 'Wireless Earbuds Pro'  AS name, 'Premium 30hr battery, ANC noise cancellation, IPX5 waterproof' AS description, 49.99 AS price_usd, 150 AS stock, 'Electronics' AS category UNION ALL
  SELECT 'Smart Watch Ultra',     'Health & GPS tracking, 7-day battery, AMOLED display',                  129.99, 80,  'Electronics' UNION ALL
  SELECT 'Leather Crossbody Bag', 'Genuine full-grain leather, adjustable strap, 6 pockets',               79.99, 60,  'Fashion'     UNION ALL
  SELECT 'Portable USB Blender',  'USB-C rechargeable, 6 titanium blades, BPA-free 400ml cup',             34.99, 200, 'Kitchen'     UNION ALL
  SELECT 'LED Desk Lamp Pro',     'Touch dim, 5 colour temps, built-in USB-A/C charging ports',            27.99, 120, 'Home'        UNION ALL
  SELECT 'Running Shoes X1',      'Lightweight mesh upper, responsive cushioning, unisex sizing',           64.99, 90,  'Sports'
) p ON 1=1
WHERE a.username = 'seller'
LIMIT 6;

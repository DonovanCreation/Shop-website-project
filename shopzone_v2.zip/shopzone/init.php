<?php
session_start();
require_once __DIR__ . '/config.php';

// ================================================================
//  DATABASE  — MySQL via PDO
// ================================================================
function getDB(): PDO {
    static $db = null;
    if ($db === null) {
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        ];
        try {
            $db = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(503);
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
            <title>Database Error – ShopZone</title>
            <style>
              body{font-family:sans-serif;background:#1a1a2e;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
              .box{background:#16213e;border:2px solid #FF4500;border-radius:16px;padding:40px;max-width:560px;text-align:center}
              h2{color:#FF4500;margin-bottom:12px}code{background:#0f3460;padding:4px 10px;border-radius:6px;font-size:13px;word-break:break-all}
            </style></head><body><div class="box">
            <h2>⚠️ Database Connection Failed</h2>
            <p>ShopZone cannot connect to MySQL. Please check <code>config.php</code> and ensure:</p>
            <ol style="text-align:left;line-height:2">
              <li>MySQL / MariaDB server is running</li>
              <li>Database <strong>db_shopzone</strong> exists — import <code>db_shopzone.sql</code> via phpMyAdmin</li>
              <li>Credentials in <code>config.php</code> are correct</li>
            </ol>
            <p style="margin-top:16px;font-size:13px;color:#aaa">Error: ' . htmlspecialchars($e->getMessage()) . '</p>
            </div></body></html>';
            exit;
        }
    }
    return $db;
}

// ================================================================
//  AUTH HELPERS
// ================================================================
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function getCurrentUser(): ?array {
    if (!isLoggedIn()) return null;
    $st = getDB()->prepare("SELECT * FROM db_account WHERE id = ?");
    $st->execute([$_SESSION['user_id']]);
    return $st->fetch() ?: null;
}

function requireLogin(): void {
    if (!isLoggedIn()) { header('Location: login.php'); exit; }
}

function requireRole(string $role): void {
    requireLogin();
    if ($_SESSION['role'] !== $role) { header('Location: index.php'); exit; }
}

function getCartCount(): int {
    if (!isLoggedIn() || ($_SESSION['role'] ?? '') !== 'customer') return 0;
    $st = getDB()->prepare("SELECT COALESCE(SUM(quantity),0) FROM cart WHERE customer_id = ?");
    $st->execute([$_SESSION['user_id']]);
    return (int)$st->fetchColumn();
}

// ================================================================
//  SESSION PREFERENCE HELPERS
// ================================================================
function getUserPref(string $key, string $default = ''): string {
    return $_SESSION['prefs'][$key] ?? $default;
}

function getLang(): string    { return getUserPref('language', 'en'); }
function getCountry(): string { return getUserPref('country',  'USA'); }
function getCurrency(): string{ return getUserPref('currency', 'USD'); }

// ================================================================
//  SYNC SESSION PREFS FROM DB  (called after login / pref save)
// ================================================================
function syncSessionPrefs(array $user): void {
    $_SESSION['prefs'] = [
        'language' => $user['language'] ?? 'en',
        'country'  => $user['country']  ?? 'USA',
        'currency' => $user['currency'] ?? 'USD',
    ];
}

// ================================================================
//  CURRENCY
// ================================================================
const CURRENCY_RATES = [
    'USD' => ['rate'=>1.00,    'symbol'=>'$',  'code'=>'USD','name'=>'US Dollar',           'decimals'=>2],
    'JPY' => ['rate'=>155.0,   'symbol'=>'¥',  'code'=>'JPY','name'=>'Japanese Yen (円)',    'decimals'=>0],
    'KRW' => ['rate'=>1370.0,  'symbol'=>'₩',  'code'=>'KRW','name'=>'Korean Won (원)',      'decimals'=>0],
    'CNY' => ['rate'=>7.25,    'symbol'=>'¥',  'code'=>'CNY','name'=>'Chinese Yuan (人民币)','decimals'=>2],
    'IDR' => ['rate'=>16200.0, 'symbol'=>'Rp', 'code'=>'IDR','name'=>'Indonesian Rupiah',   'decimals'=>0],
];

function convertPrice(float $usd): float {
    return $usd * (CURRENCY_RATES[getCurrency()]['rate'] ?? 1.0);
}

function formatPrice(float $usd): string {
    $cur  = getCurrency();
    $info = CURRENCY_RATES[$cur];
    $local = $usd * $info['rate'];
    $formatted = number_format($local, $info['decimals']);
    if ($cur === 'IDR') return $info['symbol'] . ' ' . $formatted;
    if ($cur === 'CNY') return $info['symbol'] . $formatted . ' 元';
    return $info['symbol'] . $formatted;
}

function currencySymbol(): string {
    return CURRENCY_RATES[getCurrency()]['symbol'] ?? '$';
}

// ================================================================
//  COUNTRY DEFAULTS
// ================================================================
const COUNTRY_DEFAULTS = [
    'USA'       => ['currency'=>'USD','language'=>'en','flag'=>'🇺🇸'],
    'Japan'     => ['currency'=>'JPY','language'=>'ja','flag'=>'🇯🇵'],
    'China'     => ['currency'=>'CNY','language'=>'zh','flag'=>'🇨🇳'],
    'Korea'     => ['currency'=>'KRW','language'=>'ko','flag'=>'🇰🇷'],
    'Indonesia' => ['currency'=>'IDR','language'=>'id','flag'=>'🇮🇩'],
];

// ================================================================
//  DELIVERY SERVICES  (price in USD)
// ================================================================
function getDeliveryServices(): array {
    $country = getCountry();
    $all = [
        'USA' => [
            'fedex_standard' => ['name'=>'FedEx Standard',  'logo'=>'📦','time'=>'3-5 business days', 'price'=>8.99],
            'fedex_express'  => ['name'=>'FedEx Express',   'logo'=>'⚡','time'=>'1-2 business days', 'price'=>18.99],
            'ups_ground'     => ['name'=>'UPS Ground',      'logo'=>'🟤','time'=>'3-7 business days', 'price'=>7.99],
            'ups_express'    => ['name'=>'UPS Express',     'logo'=>'🚀','time'=>'1-3 business days', 'price'=>16.99],
            'usps_priority'  => ['name'=>'USPS Priority',  'logo'=>'🏛️','time'=>'2-3 business days', 'price'=>9.99],
            'dhl_express'    => ['name'=>'DHL Express',     'logo'=>'✈️','time'=>'2-4 business days', 'price'=>14.99],
            'free_shipping'  => ['name'=>'Free Shipping',  'logo'=>'🎁','time'=>'7-14 business days','price'=>0.00],
        ],
        'Japan' => [
            'yamato'         => ['name'=>'ヤマト運輸 (Yamato TA-Q-BIN)',  'logo'=>'🐱','time'=>'翌日〜3日',   'price'=>5.99],
            'yamato_cool'    => ['name'=>'ヤマトクール宅急便',             'logo'=>'❄️','time'=>'翌日〜3日',   'price'=>9.99],
            'sagawa'         => ['name'=>'佐川急便 (Sagawa Express)',     'logo'=>'🚐','time'=>'翌日〜2日',   'price'=>5.49],
            'japan_post'     => ['name'=>'ゆうパック (Japan Post)',       'logo'=>'📮','time'=>'翌日〜4日',   'price'=>4.99],
            'seino'          => ['name'=>'西濃運輸 (Seino Transport)',    'logo'=>'🏭','time'=>'2〜5日',      'price'=>6.49],
            'fukuyama'       => ['name'=>'福山通運 (Fukuyama)',           'logo'=>'🚛','time'=>'1〜3日',      'price'=>5.99],
            'free_shipping'  => ['name'=>'送料無料 (Free Shipping)',      'logo'=>'🎁','time'=>'7〜14日',     'price'=>0.00],
        ],
        'China' => [
            'sf_express'     => ['name'=>'顺丰速递 (SF Express)',         'logo'=>'🟦','time'=>'1-3个工作日', 'price'=>4.99],
            'zto'            => ['name'=>'中通快递 (ZTO Express)',        'logo'=>'🔵','time'=>'3-5个工作日', 'price'=>1.99],
            'sto'            => ['name'=>'申通快递 (STO Express)',        'logo'=>'🟠','time'=>'3-5个工作日', 'price'=>1.99],
            'yto'            => ['name'=>'圆通速递 (YTO Express)',        'logo'=>'🟡','time'=>'3-5个工作日', 'price'=>1.99],
            'jd_logistics'   => ['name'=>'京东物流 (JD Logistics)',       'logo'=>'🔴','time'=>'当日/次日达', 'price'=>6.99],
            'cainiao'        => ['name'=>'菜鸟速递 (Cainiao)',            'logo'=>'🐦','time'=>'2-4个工作日', 'price'=>2.49],
            'china_post'     => ['name'=>'中国邮政 (China Post)',         'logo'=>'📮','time'=>'5-10个工作日','price'=>0.99],
            'free_shipping'  => ['name'=>'免费配送 (Free)',               'logo'=>'🎁','time'=>'10-15工作日', 'price'=>0.00],
        ],
        'Korea' => [
            'cj_logistics'   => ['name'=>'CJ대한통운 (CJ Logistics)',    'logo'=>'📦','time'=>'1-2 영업일',  'price'=>4.99],
            'lotte'          => ['name'=>'롯데택배 (Lotte Delivery)',    'logo'=>'🟠','time'=>'1-3 영업일',  'price'=>4.49],
            'hanjin'         => ['name'=>'한진택배 (Hanjin)',            'logo'=>'🟤','time'=>'1-3 영업일',  'price'=>4.49],
            'korea_post'     => ['name'=>'우체국택배 (Korea Post)',      'logo'=>'📮','time'=>'2-4 영업일',  'price'=>3.99],
            'gs_postbox'     => ['name'=>'GS편의점택배',                 'logo'=>'🟢','time'=>'2-4 영업일',  'price'=>3.49],
            'logen'          => ['name'=>'로젠택배 (Logen)',             'logo'=>'🔵','time'=>'1-3 영업일',  'price'=>3.99],
            'free_shipping'  => ['name'=>'무료배송 (Free Shipping)',     'logo'=>'🎁','time'=>'7-14 영업일', 'price'=>0.00],
        ],
        'Indonesia' => [
            'jne_reg'        => ['name'=>'JNE Reguler',                  'logo'=>'🔴','time'=>'2-5 hari kerja', 'price'=>2.99],
            'jne_yes'        => ['name'=>'JNE YES (Yakin Esok Sampai)',  'logo'=>'⚡','time'=>'Esok hari',      'price'=>6.99],
            'jnt'            => ['name'=>'J&T Express',                  'logo'=>'🟢','time'=>'1-4 hari kerja', 'price'=>2.49],
            'sicepat'        => ['name'=>'SiCepat Halu',                 'logo'=>'🚀','time'=>'1-3 hari kerja', 'price'=>2.99],
            'pos_indonesia'  => ['name'=>'Pos Indonesia',                'logo'=>'📮','time'=>'3-7 hari kerja', 'price'=>1.99],
            'anteraja'       => ['name'=>'Anteraja',                     'logo'=>'🟡','time'=>'1-3 hari kerja', 'price'=>2.49],
            'ninja_xpress'   => ['name'=>'Ninja Xpress',                 'logo'=>'🥷','time'=>'2-5 hari kerja', 'price'=>2.29],
            'free_shipping'  => ['name'=>'Gratis Ongkir (Free)',         'logo'=>'🎁','time'=>'7-14 hari kerja','price'=>0.00],
        ],
    ];
    return $all[$country] ?? $all['USA'];
}

// ================================================================
//  TRANSLATIONS
// ================================================================
function t(string $key): string {
    require_once __DIR__ . '/lang.php';
    $lang  = getLang();
    $trans = getTranslations();
    return $trans[$lang][$key] ?? $trans['en'][$key] ?? $key;
}

// ================================================================
//  FLASH MESSAGES
// ================================================================
function setFlash(string $type, string $msg): void {
    $_SESSION['flash'] = ['type'=>$type, 'msg'=>$msg];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) { $f=$_SESSION['flash']; unset($_SESSION['flash']); return $f; }
    return null;
}

function renderFlash(): void {
    $f = getFlash();
    if ($f) {
        $icon = $f['type']==='success' ? '✓' : '✕';
        echo "<div class='flash flash-{$f['type']}'><span class='flash-icon'>{$icon}</span>" . htmlspecialchars($f['msg']) . "</div>";
    }
}
?>

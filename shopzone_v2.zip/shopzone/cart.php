<?php
require_once 'layout.php';
requireRole('customer');

$db     = getDB();
$custId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_item'])) {
    $db->prepare("DELETE FROM cart WHERE id=? AND customer_id=?")->execute([(int)$_POST['cart_id'], $custId]);
    header('Location: cart.php'); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty'])) {
    $db->prepare("UPDATE cart SET quantity=? WHERE id=? AND customer_id=?")
       ->execute([max(1,(int)$_POST['quantity']), (int)$_POST['cart_id'], $custId]);
    header('Location: cart.php'); exit;
}

$st = $db->prepare("
    SELECT c.id AS cart_id, c.quantity, p.id AS product_id,
           p.name, p.price_usd AS price, p.stock, p.image, p.category
    FROM cart c JOIN db_product p ON c.product_id=p.id
    WHERE c.customer_id=?
");
$st->execute([$custId]);
$cartItems = $st->fetchAll();

$subtotalUSD = 0;
foreach ($cartItems as $item) $subtotalUSD += $item['price'] * $item['quantity'];
$shippingUSD = $subtotalUSD > 50 ? 0 : 5.99;
$totalUSD    = $subtotalUSD + $shippingUSD;

renderHead(t('cart'));
renderSidebar('cart');
renderTopbar('🛒 ' . t('cart'));
renderFlash();
?>

<?php if (empty($cartItems)): ?>
  <div class="empty-state fade-in">
    <div class="empty-icon">🛒</div>
    <div class="empty-title">Your cart is empty</div>
    <a href="shop.php" class="btn btn-primary btn-lg" style="margin-top:16px">🛍️ <?= t('continue_shopping') ?></a>
  </div>
<?php else: ?>
<div class="cart-layout fade-in">
  <div class="card">
    <div class="card-header">
      <h2>🛒 <?= t('cart') ?> <span style="font-weight:400;font-size:16px;color:var(--text-light)">(<?= count($cartItems) ?> items)</span></h2>
      <a href="shop.php" class="btn btn-sm btn-outline">+ <?= t('continue_shopping') ?></a>
    </div>
    <?php foreach ($cartItems as $item): ?>
      <div class="cart-item cart-row" data-price="<?= $item['price'] ?>">
        <div class="cart-item-img">
          <?= productImage($item) ?>
        </div>
        <div class="cart-item-info">
          <div class="cart-item-name"><?= htmlspecialchars($item['name']) ?></div>
          <div class="cart-item-price"><?= formatPrice($item['price']) ?> each</div>
        </div>
        <form method="POST" data-autosubmit="1">
          <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
          <div class="qty-control">
            <button type="button" class="qty-btn" data-action="dec">−</button>
            <input type="number" name="quantity" class="qty-val" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?>">
            <button type="button" class="qty-btn" data-action="inc">+</button>
          </div>
          <button type="submit" name="update_qty" value="1" style="display:none">Update</button>
        </form>
        <div class="row-total" style="font-family:'Outfit',sans-serif;font-weight:800;font-size:16px;min-width:80px;text-align:right">
          <?= formatPrice($item['price'] * $item['quantity']) ?>
        </div>
        <form method="POST">
          <input type="hidden" name="cart_id" value="<?= $item['cart_id'] ?>">
          <button type="submit" name="remove_item" value="1" class="btn btn-sm btn-danger">✕</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="order-summary">
    <h3>📋 Order Summary</h3>
    <div class="summary-row">
      <span>Subtotal</span>
      <span id="summary-subtotal"><?= formatPrice($subtotalUSD) ?></span>
    </div>
    <div class="summary-row">
      <span><?= t('shipping_fee') ?></span>
      <span id="summary-shipping"><?= $shippingUSD == 0 ? 'FREE' : formatPrice($shippingUSD) ?></span>
    </div>
    <?php if ($shippingUSD == 0): ?>
      <div style="font-size:12px;color:var(--accent-green);font-weight:600;padding:4px 0">✅ Free shipping!</div>
    <?php else: ?>
      <div style="font-size:12px;color:var(--text-light);padding:4px 0">💡 Add <?= formatPrice(50 - $subtotalUSD) ?> more for free shipping</div>
    <?php endif; ?>
    <div class="summary-total">
      <span>Total</span>
      <span id="summary-total" style="color:var(--primary)"><?= formatPrice($totalUSD) ?></span>
    </div>
    <br>
    <a href="checkout.php" class="btn btn-primary btn-block btn-lg">🚀 <?= t('checkout') ?> →</a>
  </div>
</div>
<?php endif; ?>

<?php renderFooter(); ?>

<?php
require_once 'layout.php';
requireRole('customer');

$db      = getDB();
$orderId = (int)($_GET['id'] ?? 0);
$custId  = $_SESSION['user_id'];

$st = $db->prepare("SELECT * FROM orders WHERE id=? AND customer_id=?");
$st->execute([$orderId, $custId]);
$order = $st->fetch();
if (!$order) { header('Location: shop.php'); exit; }

$st = $db->prepare("SELECT * FROM order_items WHERE order_id=?");
$st->execute([$orderId]);
$items = $st->fetchAll();

renderHead('Order Confirmed');
renderSidebar('orders');
renderTopbar('✅ Order Confirmed!');
?>

<div class="card fade-in" style="max-width:680px;margin:0 auto">
  <div class="card-body">
    <div class="success-page">
      <div class="success-icon">✓</div>
      <h2 style="font-size:28px;margin-bottom:8px"><?= t('order_confirmed') ?></h2>
      <p style="color:var(--text-light);margin-bottom:32px">Thank you! Your order is being processed.</p>

      <div style="background:var(--bg);border-radius:14px;padding:24px;text-align:left;margin-bottom:24px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:14px">
          <div>
            <div style="font-size:11px;color:var(--text-light);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Order Number</div>
            <div style="font-weight:700;font-size:18px">#<?= $order['id'] ?></div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--text-light);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Date</div>
            <div style="font-weight:600"><?= date('M d, Y H:i', strtotime($order['created_at'])) ?></div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--text-light);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Delivery</div>
            <div style="font-weight:600">🚚 <?= htmlspecialchars($order['delivery_service']) ?></div>
          </div>
          <div>
            <div style="font-size:11px;color:var(--text-light);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Payment</div>
            <div style="font-weight:600">💳 <?= htmlspecialchars($order['payment_method']) ?></div>
          </div>
          <div style="grid-column:1/-1">
            <div style="font-size:11px;color:var(--text-light);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Shipping To</div>
            <div style="font-weight:600">📍 <?= htmlspecialchars($order['address']) ?>, <?= htmlspecialchars($order['city']) ?></div>
          </div>
        </div>
      </div>

      <div style="text-align:left;margin-bottom:24px">
        <h3 style="margin-bottom:12px">📦 Items Ordered</h3>
        <?php foreach ($items as $item): ?>
          <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px">
            <div><span style="font-weight:600"><?= htmlspecialchars($item['product_name']) ?></span> <span style="color:var(--text-light)">× <?= $item['quantity'] ?></span></div>
            <span style="font-weight:700"><?= formatPrice($item['price_usd'] * $item['quantity']) ?></span>
          </div>
        <?php endforeach; ?>
        <div style="display:flex;justify-content:space-between;padding-top:14px;font-family:'Outfit',sans-serif;font-size:20px;font-weight:800">
          <span>Total</span>
          <span style="color:var(--primary)"><?= formatPrice($order['total_usd']) ?></span>
        </div>
      </div>

      <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
        <a href="customer_orders.php" class="btn btn-secondary btn-lg">📋 <?= t('orders') ?></a>
        <a href="shop.php" class="btn btn-primary btn-lg">🛍️ <?= t('continue_shopping') ?></a>
      </div>
    </div>
  </div>
</div>

<?php renderFooter(); ?>

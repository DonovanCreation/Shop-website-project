// ===== ShopZone JavaScript =====

document.addEventListener('DOMContentLoaded', function () {

  // ---- Sidebar mobile toggle ----
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.querySelector('.sidebar-overlay');
  const menuToggle = document.querySelector('.menu-toggle');

  if (menuToggle) {
    menuToggle.addEventListener('click', () => {
      sidebar?.classList.toggle('open');
      overlay?.classList.toggle('show');
    });
  }

  if (overlay) {
    overlay.addEventListener('click', () => {
      sidebar?.classList.remove('open');
      overlay.classList.remove('show');
    });
  }

  // ---- Demo account quick fill ----
  const demoItems = document.querySelectorAll('.demo-item');
  demoItems.forEach(item => {
    item.addEventListener('click', () => {
      const u = item.dataset.user;
      const p = item.dataset.pass;
      const uInput = document.querySelector('input[name="username"]');
      const pInput = document.querySelector('input[name="password"]');
      if (uInput && pInput) {
        uInput.value = u;
        pInput.value = p;
        animateField(uInput);
        animateField(pInput);
      }
    });
  });

  function animateField(el) {
    el.style.transition = 'background 0.2s';
    el.style.background = 'rgba(255,69,0,0.06)';
    setTimeout(() => el.style.background = '', 500);
  }

  // ---- Image upload preview ----
  const fileInputs = document.querySelectorAll('input[type="file"][name="image"]');
  fileInputs.forEach(input => {
    const area = input.closest('.upload-area');
    const preview = area?.querySelector('.upload-preview');
    const uploadText = area?.querySelector('.upload-text');

    input.addEventListener('change', () => {
      const file = input.files[0];
      if (file && preview) {
        const reader = new FileReader();
        reader.onload = e => {
          preview.src = e.target.result;
          preview.style.display = 'block';
          if (uploadText) uploadText.textContent = file.name;
        };
        reader.readAsDataURL(file);
      }
    });

    // Drag & drop
    if (area) {
      area.addEventListener('dragover', e => {
        e.preventDefault();
        area.classList.add('dragover');
      });
      area.addEventListener('dragleave', () => area.classList.remove('dragover'));
      area.addEventListener('drop', e => {
        e.preventDefault();
        area.classList.remove('dragover');
        if (e.dataTransfer.files[0]) {
          input.files = e.dataTransfer.files;
          input.dispatchEvent(new Event('change'));
        }
      });
    }
  });

  // ---- Payment options (visual selection) ----
  const paymentOptions = document.querySelectorAll('.payment-option');
  paymentOptions.forEach(opt => {
    opt.addEventListener('click', () => {
      paymentOptions.forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      const radio = opt.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });

  // ---- Delivery options (visual selection) ----
  const deliveryOptions = document.querySelectorAll('.delivery-option');
  deliveryOptions.forEach(opt => {
    opt.addEventListener('click', () => {
      deliveryOptions.forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      const radio = opt.querySelector('input[type="radio"]');
      if (radio) radio.checked = true;
    });
  });

  // ---- Quantity controls ----
  document.querySelectorAll('.qty-btn').forEach(btn => {
    btn.addEventListener('click', function () {
      const input = this.closest('.qty-control')?.querySelector('.qty-val');
      if (!input) return;
      const delta = this.dataset.action === 'inc' ? 1 : -1;
      let val = parseInt(input.value) + delta;
      val = Math.max(1, Math.min(99, val));
      input.value = val;

      // If in cart, submit form automatically
      const form = this.closest('form');
      if (form && form.dataset.autosubmit) {
        clearTimeout(window._qtyTimeout);
        window._qtyTimeout = setTimeout(() => form.submit(), 500);
      }
    });
  });

  // ---- Modal handling ----
  const modalTriggers = document.querySelectorAll('[data-modal]');
  modalTriggers.forEach(btn => {
    btn.addEventListener('click', () => {
      const modal = document.querySelector('#' + btn.dataset.modal);
      if (modal) modal.classList.add('show');
    });
  });

  document.querySelectorAll('.modal-close, .modal-overlay').forEach(el => {
    el.addEventListener('click', function (e) {
      if (e.target === this || this.classList.contains('modal-close')) {
        this.closest('.modal-overlay')?.classList.remove('show');
        const overlay = document.querySelector('.modal-overlay');
        if (overlay && !e.target.closest('.modal')) overlay.classList.remove('show');
      }
    });
  });

  document.querySelectorAll('.modal').forEach(m => {
    m.addEventListener('click', e => e.stopPropagation());
  });

  // ---- Flash auto-hide ----
  const flash = document.querySelector('.flash');
  if (flash) {
    setTimeout(() => {
      flash.style.transition = 'opacity 0.5s, transform 0.5s';
      flash.style.opacity = '0';
      flash.style.transform = 'translateY(-8px)';
      setTimeout(() => flash.remove(), 500);
    }, 4000);
  }

  // ---- Delete confirmation ----
  document.querySelectorAll('[data-confirm]').forEach(btn => {
    btn.addEventListener('click', function (e) {
      if (!confirm(this.dataset.confirm || 'Are you sure?')) {
        e.preventDefault();
      }
    });
  });

  // ---- Search filter (live, client-side for product grid) ----
  const searchInput = document.querySelector('#live-search');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      const q = this.value.toLowerCase();
      document.querySelectorAll('.product-card[data-name]').forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const cat = (card.dataset.category || '').toLowerCase();
        card.style.display = (name.includes(q) || cat.includes(q)) ? '' : 'none';
      });
    });
  }

  // ---- Cart total live update ----
  updateCartSummary();

  function updateCartSummary() {
    const rows = document.querySelectorAll('.cart-row');
    let subtotal = 0;
    rows.forEach(row => {
      const price = parseFloat(row.dataset.price || 0);
      const qty = parseInt(row.querySelector('.qty-val')?.value || 0);
      const rowTotal = price * qty;
      const totalEl = row.querySelector('.row-total');
      if (totalEl) totalEl.textContent = '$' + rowTotal.toFixed(2);
      subtotal += rowTotal;
    });

    const subtotalEl = document.querySelector('#summary-subtotal');
    const shippingEl = document.querySelector('#summary-shipping');
    const totalEl = document.querySelector('#summary-total');

    if (subtotalEl) subtotalEl.textContent = '$' + subtotal.toFixed(2);

    const shippingCost = subtotal > 50 ? 0 : 5.99;
    if (shippingEl) shippingEl.textContent = shippingCost === 0 ? 'FREE' : '$' + shippingCost.toFixed(2);

    if (totalEl) totalEl.textContent = '$' + (subtotal + shippingCost).toFixed(2);
  }

  // Qty change triggers summary update
  document.querySelectorAll('.cart-row .qty-val').forEach(input => {
    input.addEventListener('change', updateCartSummary);
  });

  document.querySelectorAll('.cart-row .qty-btn').forEach(btn => {
    btn.addEventListener('click', () => setTimeout(updateCartSummary, 10));
  });

  // ---- Category chips ----
  const catChips = document.querySelectorAll('.filter-chip[data-cat]');
  catChips.forEach(chip => {
    chip.addEventListener('click', function () {
      catChips.forEach(c => c.classList.remove('active'));
      this.classList.add('active');
      const cat = this.dataset.cat;
      document.querySelectorAll('.product-card[data-category]').forEach(card => {
        if (cat === 'all' || card.dataset.category === cat) {
          card.style.display = '';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });

  // ---- Sort products ----
  const sortSelect = document.querySelector('#sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', function () {
      const grid = document.querySelector('.products-grid');
      if (!grid) return;
      const cards = Array.from(grid.querySelectorAll('.product-card'));
      cards.sort((a, b) => {
        const pa = parseFloat(a.dataset.price || 0);
        const pb = parseFloat(b.dataset.price || 0);
        if (this.value === 'price-asc') return pa - pb;
        if (this.value === 'price-desc') return pb - pa;
        if (this.value === 'name') return (a.dataset.name || '').localeCompare(b.dataset.name || '');
        return 0;
      });
      cards.forEach(c => grid.appendChild(c));
    });
  }

  // ---- Toast notification (add to cart) ----
  window.showToast = function (msg, type = 'success') {
    const existing = document.querySelector('.sz-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'sz-toast';
    toast.innerHTML = `<span>${type === 'success' ? '✓' : '✕'}</span> ${msg}`;
    toast.style.cssText = `
      position: fixed; bottom: 24px; right: 24px; z-index: 9999;
      background: ${type === 'success' ? '#1a1a2e' : '#dc2626'};
      color: #fff; padding: 14px 20px; border-radius: 12px;
      font-family: 'Nunito', sans-serif; font-size: 14px; font-weight: 600;
      display: flex; align-items: center; gap: 10px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.25);
      animation: slideUp 0.4s cubic-bezier(0.34,1.56,0.64,1);
    `;

    const style = document.createElement('style');
    style.textContent = `@keyframes slideUp {
      from { transform: translateY(40px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }`;
    document.head.appendChild(style);
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(20px)';
      toast.style.transition = 'all 0.3s';
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  };

});

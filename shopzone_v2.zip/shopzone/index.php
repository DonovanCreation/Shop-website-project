<?php
require_once 'init.php';
requireLogin();
if ($_SESSION['role'] === 'seller') {
    header('Location: seller.php');
} else {
    header('Location: shop.php');
}
exit;
?>

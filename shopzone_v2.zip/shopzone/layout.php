<?php
require_once __DIR__ . '/init.php';

function renderHead(string $title = 'ShopZone'): void {
    $lang = getLang();
    echo "<!DOCTYPE html>
<html lang=\"{$lang}\">
<head>
<meta charset=\"UTF-8\">
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
<title>" . htmlspecialchars($title) . " – ShopZone</title>
<link rel=\"stylesheet\" href=\"style.css\">
</head>
<body>";
}

function renderSidebar(string $active = ''): void {
    $user      = getCurrentUser();
    $role      = $_SESSION['role'] ?? '';
    $cartCount = getCartCount();
    $initial   = strtoupper(substr($user['username'] ?? 'U', 0, 1));
    $country   = getCountry();
    $flag      = COUNTRY_DEFAULTS[$country]['flag'] ?? '🌐';

    $sellerNav = [
        ['icon'=>'📊','label'=>t('home'),         'href'=>'seller.php',        'id'=>'dashboard'],
        ['icon'=>'📦','label'=>t('my_listings'),   'href'=>'seller.php',        'id'=>'products'],
        ['icon'=>'➕','label'=>t('add_product'),   'href'=>'product_add.php',   'id'=>'add_product'],
        ['icon'=>'🧾','label'=>t('seller_orders'), 'href'=>'seller_orders.php', 'id'=>'orders'],
        ['icon'=>'⚙️','label'=>t('settings'),      'href'=>'settings.php',      'id'=>'settings'],
    ];

    $customerNav = [
        ['icon'=>'🏠','label'=>t('home'),    'href'=>'shop.php',            'id'=>'shop'],
        ['icon'=>'🛒','label'=>t('cart'),    'href'=>'cart.php',            'id'=>'cart','badge'=>$cartCount],
        ['icon'=>'📋','label'=>t('orders'),  'href'=>'customer_orders.php', 'id'=>'orders'],
        ['icon'=>'⚙️','label'=>t('settings'),'href'=>'settings.php',        'id'=>'settings'],
    ];

    $nav       = $role === 'seller' ? $sellerNav : $customerNav;
    $roleLabel = $role === 'seller' ? '🏪 Seller' : '🛒 Customer';
    $curLabel  = formatPrice(1); // shows "¥155" etc. as indicator

    echo "<div class='sidebar-overlay'></div>";
    echo "<aside class='sidebar'>";
    echo "<div class='sidebar-logo'>
        <div class='logo-icon'>🛍️</div>
        <div class='logo-text'>Shop<span>Zone</span></div>
      </div>";

    // Country + currency indicator
    echo "<div class='sidebar-country'>
        <span class='country-flag'>{$flag}</span>
        <span class='country-name'>{$country}</span>
        <span class='country-cur'>" . getCurrency() . "</span>
      </div>";

    echo "<nav class='sidebar-nav'>";
    echo "<div class='nav-section-label'>Menu</div>";
    foreach ($nav as $item) {
        $cls   = $active === $item['id'] ? 'active' : '';
        $badge = (isset($item['badge']) && $item['badge'] > 0)
            ? "<span class='cart-badge' style='position:static;margin-left:auto'>{$item['badge']}</span>"
            : '';
        echo "<a href='{$item['href']}' class='nav-item {$cls}'>
            <span class='nav-icon'>{$item['icon']}</span>
            <span>{$item['label']}</span>{$badge}
          </a>";
    }
    echo "</nav>";

    echo "<div class='sidebar-footer'>
        <div class='user-badge'>
          <div class='user-avatar'>{$initial}</div>
          <div class='user-info'>
            <div class='user-name'>" . htmlspecialchars($user['username'] ?? '') . "</div>
            <div class='user-role'>{$roleLabel}</div>
          </div>
        </div>
      </div>";
    echo "</aside>";
    echo "<div class='main-content'>";
}

function renderTopbar(string $title, bool $showSearch = false, bool $showCart = false): void {
    $cartCount = getCartCount();
    echo "<header class='topbar'>
        <button class='menu-toggle' aria-label='Menu'>☰</button>
        <h1 class='topbar-title'>" . htmlspecialchars($title) . "</h1>";

    if ($showSearch) {
        echo "<div class='search-bar'>
            <span class='search-icon'>🔍</span>
            <input type='text' id='live-search' placeholder='" . t('search') . "'>
          </div>";
    }

    // Currency display pill
    $cur   = getCurrency();
    $flag  = COUNTRY_DEFAULTS[getCountry()]['flag'] ?? '🌐';
    echo "<a href='settings.php' class='currency-pill' title='Change in Settings'>
        {$flag} {$cur}
      </a>";

    if ($showCart) {
        $badge = $cartCount > 0 ? "<span class='cart-badge'>{$cartCount}</span>" : '';
        echo "<a href='cart.php' class='cart-btn'>🛒{$badge}</a>";
    }
    echo "</header>";
    echo "<main class='page-content'>";
}

function renderFooter(): void {
    echo "</main></div>";
    echo "<script src='script.js'></script>";
    echo "</body></html>";
}

function categoryEmoji(string $cat): string {
    $map = [
        'Electronics'=>'🔌','Fashion'=>'👗','Kitchen'=>'🍳','Home'=>'🏠',
        'Sports'=>'⚽','Books'=>'📚','Beauty'=>'💄','Toys'=>'🧸',
        'Garden'=>'🌿','General'=>'📦',
    ];
    return $map[$cat] ?? '📦';
}

function productImage(array $product): string {
    if (!empty($product['image']) && file_exists(UPLOAD_DIR . $product['image'])) {
        return "<img src='" . UPLOAD_URL . htmlspecialchars($product['image']) . "' alt='" . htmlspecialchars($product['name']) . "'>";
    }
    return categoryEmoji($product['category'] ?? 'General');
}
?>

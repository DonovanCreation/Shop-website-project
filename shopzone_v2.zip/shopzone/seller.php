<?php
require_once 'layout.php';
requireRole('seller');

$db       = getDB();
$sellerId = $_SESSION['user_id'];

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $pid = (int)$_POST['product_id'];
    $st  = $db->prepare("SELECT image FROM db_product WHERE id=? AND seller_id=?");
    $st->execute([$pid, $sellerId]);
    $prod = $st->fetch();
    if ($prod) {
        if ($prod['image'] && file_exists(UPLOAD_DIR . $prod['image'])) {
            unlink(UPLOAD_DIR . $prod['image']);
        }
        $db->prepare("DELETE FROM db_product WHERE id=? AND seller_id=?")->execute([$pid, $sellerId]);
        setFlash('success', t('product_deleted'));
    }
    header('Location: seller.php'); exit;
}

// Stats from db_product
$pst = $db->prepare("SELECT COUNT(*) AS cnt FROM db_product WHERE seller_id=?");
$pst->execute([$sellerId]);
$pstats = $pst->fetch();

$ost = $db->prepare("
    SELECT COUNT(DISTINCT o.id) AS cnt, COALESCE(SUM(oi.price_usd * oi.quantity),0) AS rev
    FROM orders o
    JOIN order_items oi ON o.id=oi.order_id
    JOIN db_product p ON oi.product_id=p.id
    WHERE p.seller_id=?
");
$ost->execute([$sellerId]);
$ostats = $ost->fetch();

$search = trim($_GET['s'] ?? '');
$st = $db->prepare("SELECT * FROM db_product WHERE seller_id=? AND name LIKE ? ORDER BY created_at DESC");
$st->execute([$sellerId, "%{$search}%"]);
$products = $st->fetchAll();

renderHead(t('seller_dashboard'));
renderSidebar('dashboard');
renderTopbar(t('seller_dashboard'));
renderFlash();
?>

<div class="stats-grid fade-in">
  <div class="stat-card">
    <div class="stat-icon orange">📦</div>
    <div><div class="stat-value"><?= $pstats['cnt'] ?></div><div class="stat-label"><?= t('total_products') ?></div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue">🧾</div>
    <div><div class="stat-value"><?= $ostats['cnt'] ?></div><div class="stat-label"><?= t('total_orders') ?></div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">💰</div>
    <div><div class="stat-value"><?= formatPrice($ostats['rev']) ?></div><div class="stat-label"><?= t('revenue') ?></div></div>
  </div>
  <div class="stat-card">
    <div class="stat-icon gold">📈</div>
    <div><div class="stat-value"><?= $pstats['cnt'] > 0 ? round($ostats['cnt'] / $pstats['cnt'], 1) : 0 ?></div><div class="stat-label">Orders/Product</div></div>
  </div>
</div>

<div class="card fade-in">
  <div class="card-header">
    <h2>📦 <?= t('my_products') ?></h2>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <form method="GET" style="display:flex;gap:8px">
        <input type="text" name="s" class="form-control" style="width:220px;padding:8px 14px"
               placeholder="<?= t('search') ?>" value="<?= htmlspecialchars($search) ?>">
        <button class="btn btn-secondary btn-sm">🔍</button>
      </form>
      <a href="product_add.php" class="btn btn-primary btn-sm">➕ <?= t('add_product') ?></a>
    </div>
  </div>

  <?php if (empty($products)): ?>
    <div class="empty-state">
      <div class="empty-icon">📦</div>
      <div class="empty-title"><?= t('no_products') ?></div>
      <a href="product_add.php" class="btn btn-primary" style="margin-top:16px">➕ <?= t('add_product') ?></a>
    </div>
  <?php else: ?>
    <?php foreach ($products as $p): ?>
      <div class="product-list-item">
        <div class="product-thumb"><?= productImage($p) ?></div>
        <div class="product-list-info">
          <div class="product-list-name"><?= htmlspecialchars($p['name']) ?></div>
          <div class="product-list-meta"><?= htmlspecialchars($p['category']) ?> · <?= t('stock') ?>: <?= $p['stock'] ?> · <?= date('M d, Y', strtotime($p['created_at'])) ?></div>
        </div>
        <span class="product-list-price"><?= formatPrice($p['price_usd']) ?></span>
        <span class="badge <?= $p['stock']>0?'badge-success':'badge-danger' ?>">
          <?= $p['stock']>0?t('in_stock'):t('out_of_stock') ?>
        </span>
        <div class="product-actions">
          <a href="product_add.php?edit=<?= $p['id'] ?>" class="btn btn-sm btn-outline"><?= t('edit') ?></a>
          <form method="POST" style="display:inline">
            <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
            <button type="submit" name="delete_product" value="1" class="btn btn-sm btn-danger"
                    onclick="return confirm('Delete \'<?= addslashes($p['name']) ?>\'?')">
              <?= t('delete') ?>
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php renderFooter(); ?>

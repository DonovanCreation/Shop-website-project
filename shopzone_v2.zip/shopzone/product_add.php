<?php
require_once 'layout.php';
requireRole('seller');

$db       = getDB();
$sellerId = $_SESSION['user_id'];
$editId   = isset($_GET['edit']) ? (int)$_GET['edit'] : null;
$product  = null;

if ($editId) {
    $st = $db->prepare("SELECT * FROM db_product WHERE id=? AND seller_id=?");
    $st->execute([$editId, $sellerId]);
    $product = $st->fetch();
    if (!$product) { header('Location: seller.php'); exit; }
}

$categories = ['Electronics','Fashion','Kitchen','Home','Sports','Books','Beauty','Toys','Garden','General'];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = trim($_POST['name']        ?? '');
    $desc     = trim($_POST['description'] ?? '');
    $priceUSD = (float)($_POST['price']    ?? 0);
    $stock    = (int)($_POST['stock']      ?? 0);
    $category = $_POST['category']         ?? 'General';

    if (!$name)        $errors[] = 'Product name is required.';
    if ($priceUSD<=0)  $errors[] = 'Price must be greater than 0.';
    if ($stock<0)      $errors[] = 'Stock cannot be negative.';

    // Image upload
    $imageName = $product['image'] ?? '';
    if (!empty($_FILES['image']['name'])) {
        $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];
        if (!in_array($ext, $allowed)) {
            $errors[] = 'Invalid image format. Use JPG, PNG, GIF, or WebP.';
        } elseif ($_FILES['image']['size'] > MAX_FILE_SIZE) {
            $errors[] = 'Image must be under 5MB.';
        } elseif ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Upload error. Please try again.';
        } else {
            $newName = uniqid('prod_') . '.' . $ext;
            if (!move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $newName)) {
                $errors[] = 'Failed to save image.';
            } else {
                if ($product && $product['image'] && file_exists(UPLOAD_DIR . $product['image'])) {
                    unlink(UPLOAD_DIR . $product['image']);
                }
                $imageName = $newName;
            }
        }
    }

    if (empty($errors)) {
        if ($editId && $product) {
            $db->prepare("UPDATE db_product SET name=?,description=?,price_usd=?,stock=?,category=?,image=? WHERE id=? AND seller_id=?")
               ->execute([$name,$desc,$priceUSD,$stock,$category,$imageName,$editId,$sellerId]);
            setFlash('success', t('product_updated'));
        } else {
            $db->prepare("INSERT INTO db_product (seller_id,name,description,price_usd,stock,category,image) VALUES (?,?,?,?,?,?,?)")
               ->execute([$sellerId,$name,$desc,$priceUSD,$stock,$category,$imageName]);
            setFlash('success', t('product_added'));
        }
        header('Location: seller.php'); exit;
    }
}

$title = $editId ? t('edit') . ' Product' : t('add_product');
renderHead($title);
renderSidebar($editId ? 'products' : 'add_product');
renderTopbar($title);
renderFlash();
?>

<div class="card fade-in" style="max-width:720px">
  <div class="card-header">
    <h2><?= $editId ? '✏️ ' . t('edit') : '➕ ' . t('add_product') ?></h2>
    <a href="seller.php" class="btn btn-sm btn-outline">← <?= t('cancel') ?></a>
  </div>
  <div class="card-body">

    <?php if ($errors): ?>
      <div class="flash flash-error">
        <span class="flash-icon">✕</span>
        <div><?= implode('<br>', array_map('htmlspecialchars', $errors)) ?></div>
      </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label class="form-label">📷 <?= t('product_image') ?></label>
        <div class="upload-area">
          <input type="file" name="image" accept="image/*">
          <div class="upload-icon">📸</div>
          <div class="upload-text">Click or drag an image here</div>
          <div class="upload-hint">JPG, PNG, GIF, WebP — max 5MB</div>
          <?php if ($product && $product['image']): ?>
            <img src="<?= UPLOAD_URL . htmlspecialchars($product['image']) ?>" class="upload-preview" style="display:block">
          <?php else: ?>
            <img class="upload-preview">
          <?php endif; ?>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">📝 <?= t('product_name') ?> *</label>
        <input type="text" name="name" class="form-control" required
               value="<?= htmlspecialchars($product['name'] ?? $_POST['name'] ?? '') ?>"
               placeholder="Enter product name">
      </div>

      <div class="form-group">
        <label class="form-label">📄 <?= t('description') ?></label>
        <textarea name="description" class="form-control"><?= htmlspecialchars($product['description'] ?? $_POST['description'] ?? '') ?></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label">💰 <?= t('price') ?> (USD) *</label>
          <input type="number" name="price" class="form-control" required step="0.01" min="0.01"
                 value="<?= htmlspecialchars($product['price_usd'] ?? $_POST['price'] ?? '') ?>"
                 placeholder="0.00">
          <?php if ($editId && $product): ?>
            <div style="font-size:12px;color:var(--text-light);margin-top:4px">
              ≈ <?= formatPrice($product['price_usd']) ?> in <?= getCurrency() ?>
            </div>
          <?php endif; ?>
        </div>
        <div class="form-group">
          <label class="form-label">📊 <?= t('stock') ?> *</label>
          <input type="number" name="stock" class="form-control" required min="0"
                 value="<?= htmlspecialchars($product['stock'] ?? $_POST['stock'] ?? '') ?>"
                 placeholder="0">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">🏷️ <?= t('category') ?></label>
        <select name="category" class="form-control">
          <?php foreach ($categories as $cat): ?>
            <option value="<?= $cat ?>"
              <?= ($product['category'] ?? $_POST['category'] ?? 'General') === $cat ? 'selected' : '' ?>>
              <?= categoryEmoji($cat) ?> <?= $cat ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div style="display:flex;gap:12px;margin-top:8px">
        <button type="submit" class="btn btn-primary btn-lg">
          <?= $editId ? '💾 ' . t('update') : '➕ ' . t('save_product') ?>
        </button>
        <a href="seller.php" class="btn btn-outline btn-lg"><?= t('cancel') ?></a>
      </div>
    </form>
  </div>
</div>

<?php renderFooter(); ?>

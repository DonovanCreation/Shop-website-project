<?php
// ============================================================
//  ShopZone — MySQL / phpMyAdmin Connection Config
//  Edit these values to match your server environment
// ============================================================

define('DB_HOST',     'localhost');   // phpMyAdmin host  (usually localhost or 127.0.0.1)
define('DB_PORT',     '3306');        // MySQL port        (default 3306)
define('DB_NAME',     'db_shopzone'); // Database name
define('DB_USER',     'root');        // MySQL username    (change for production!)
define('DB_PASS',     '');            // MySQL password    (change for production!)
define('DB_CHARSET',  'utf8mb4');

// ============================================================
//  Upload directory
// ============================================================
define('UPLOAD_DIR',  __DIR__ . '/uploads/');
define('UPLOAD_URL',  'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5 MB

// ============================================================
//  App settings
// ============================================================
define('APP_NAME',    'ShopZone');
define('APP_VERSION', '2.0.0');

<?php
session_start();
$lang = $_SESSION['lang'] ?? 'en';
session_destroy();
session_start();
$_SESSION['lang'] = $lang;
header('Location: login.php');
exit;
?>
